# Testing notes

| Level | Stats total | Traits total | AP |
| --- | --- | --- | --- |
| 0 | 1 | 2 | 4 |
| 1 | 2 | 3 | 4 |
| 2 | 3 | 4 | 5 |
| 3 | 4 | 5 | 5 |
| 4 | 5 | 6 | 6 |
| 5 | 6 | 7 | 6 |
| 6 | 7 | 8 | 7 |
| 7 | 8 | 9 | 7 |
| 8 | 9 | 10 | 8 |
| 9 | 10 | 11 | 8 |

$Floor(Level/2)+4$ (Floor=Rounded Down) 

You get a number of dice equal to half your Level (rounded down), plus 4.

| Name | Requirement | Effect |
| --- | --- | --- |
| Unarmored | Core |  +1 Speed |
| Light | Core | 2*Lvl MA, 2*Lvl FA |
| Medium | Core | 3*Lvl MA, 3*Lvl FA 
-1 Speed |
| Heavy | Core | 4*Lvl MA, 4*Lvl FA 
-2 Speed |
| Shield | Core 2 | -1 DMG |
| Platemail | Body 4 | 3*Lvl MA, 5*Lvl FA  
-1 DMG, -2 Speed |
| Sita Plate | Body 6 | 3*Lvl MA, 5*Lvl FA  
-2 DMG, -2 Speed |
| Padded Leather | Mind 2 | 3*Lvl MA, 3*Lvl FA  |
| Composite Chainmail | Mind 4 | 3*Lvl MA, 3*Lvl FA 
-1 DMG |
| Soul Weave Cloak | Soul 2 | 4*Lvl MA, 2*Lvl FA
Ward 1 on yourself when you Rest |
| Soul Weave Robes | Soul 4 | 5*Lvl MA, 2*Lvl FA
Ward 2 on yourself when you Rest |

### Out of combat

Roll a number of dice (same as before) out of combat. pick a success number (>3) and every time you beet this is how well it goes. For example roll 4 dice, getting 5.6 is a success, and getting 1 success passes but only barely while getting 3+ it goes perfectly.

### Advanced character customization: Power Sources

The source of a characters power can add new depth or variance to a character’s backstory or gameplay. Below are several options to diversify your character.

<aside>
💡 These options do not have restrictions for how they are chosen and are up to the player and game master on how to implement them. For example, character who chooses “Dark Magic” as their power source but is building Body as their main stat is not necessarily a mage, but maybe entered into a pact with a Hag to gain power.

</aside>

- Ethan’s Notes on this: This is something that I want to mull over more but I think that this is either something that is optional that provides interesting side-grades / alternate playstyles to the game(?). A character without these would effectively have a Power Source of whatever their main stat is.h
- Potential point: After thinking about this a bit, Religion/Holy and Muse/Art could both just be skills. That would kinda just make this unnecessary. but also I can understand why you wouldn’t want to do that.

| Power Source | Description | Effect? |
| --- | --- | --- |
| Muse | Artist; perhaps passion devoted to an artform. Uses a form of art as an implementation for their abilities. Ie: a Bard conveying tactical information through song. A Blade Dancer elegantly dancing through a swordfight, or a Painter drawing illusions to life. |  |
| Dark Magic | Blessings of power; usually given by dark forces and usually for some price. Some examples could be a hag giving enhanced strength, in exchange for bringing back something, or a demon giving a part of their magic in exchange for someone's soul. |  |
| Wild Magic | People affected by a chaotic curse… or possibly a blessing gone awry. | Rolling 2 6s in a row or snake eyes has random effects |
| Divinity | All things holy; A priest utters a prayer of healing. A Paladin Imbues his blade with glowing light as he charges. An inquisitor tracks down the meeting place of a cult through guidance provided by his deity. |  |
| Trainee/Novice | A person training to become powerful or great though their own power. |  |
| Ancestry | Your Ancestors had great power, and it was passed on to you. |  |