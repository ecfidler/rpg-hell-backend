# Telekinesis

Tags: Attack, CC, Focus, Ranged, Utility
Cost: Contest, St 3
Effect: You Focus on moving a light object within Range 8 around, or if you target a large object or creature make a Soul Attack. On hit, Grapple the target and move them 5 tiles in any direction. This movement cannot do damage. You can spend a dice on subsequent turns to redo this action without dropping the object, provided you are within range.
This effect lasts for 3 turns, until dispelled, you cast another Focused spell, or you take damage.