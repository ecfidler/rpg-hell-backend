# Greater Illusion

Tags: Focus, Utility
Cost: Contest, St 2
Effect: Focus on creating an Illusion of your choice that is no larger in size than 3 tiles square. Range 6. A creature can make a Core Roll against you to discern if it is an illusion.
The illusion lasts for 3 turns, until dispelled, you cast another Focused spell, or you take damage. You can spend subsequent actions on the following turns to animate the illusion (no extra cost), resetting the number of turns until it dispels.