# Ice knife

Tags: Attack, Damage, Ranged, Utility
Cost: #, Attack, St 1
Effect: Create a Knife made of Ice. This knife does an extra damage and breaks after 3 turns or if thrown. On cast you can decide to spend 1 dice to create the knife or multiple dice to create and do an Attack.