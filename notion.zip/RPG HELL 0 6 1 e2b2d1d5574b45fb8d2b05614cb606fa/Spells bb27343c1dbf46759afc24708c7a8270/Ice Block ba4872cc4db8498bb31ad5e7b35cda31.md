# Ice Block

Tags: Attack, CC, Ranged, Utility
Cost: Attack, St 6
Effect: Target a creature within Range 3. If the target is unwilling, make a Soul Attack against them. On hit, the target becomes Frozen and Indestructible for 2 turns. Additionally, remove all Burn from the creature.