# Weightless

Tags: Focus, Touch, Utility
Cost: #, St 2
Effect: Focus on making a target within 5 tiles weightless. The target is no longer tied down by gravity and can move in air as though it was Water (Swim).
This effect lasts for 6 turns, until dispelled, you cast another Focused spell, or you take damage.