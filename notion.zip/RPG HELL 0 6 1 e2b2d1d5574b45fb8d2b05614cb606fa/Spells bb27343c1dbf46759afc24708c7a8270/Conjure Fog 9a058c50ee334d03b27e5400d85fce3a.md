# Conjure Fog

Tags: AOE, Focus, Ranged, Utility
Cost: #, St 1
Effect: Focus on creating an area of fog centered on a tile you can see within 8 tiles. You then summon a dense fog within Burst 3 centered on this tile. Creatures in this area can't see past 1 tile in front of them and lose 2 dice when doing ranged attacks or spells in the area.
The fog lasts 3 turns, until dispelled, you cast another Focused spell, or you take damage.