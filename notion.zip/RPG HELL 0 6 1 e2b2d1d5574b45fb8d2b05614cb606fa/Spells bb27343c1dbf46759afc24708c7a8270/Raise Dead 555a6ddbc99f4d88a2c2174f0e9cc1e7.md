# Raise Dead

Tags: Touch, Utility
Cost: ##, St 3
Effect: Target a dead creature. Curse that creature turning them into a Zombie (DR 1). You can control them using your dice on your turn to do an Action on their traits table. If you do not issue an action the Zombie does nothing.
You can control a number of Undead equal to your Soul issuing the same command to all of them with your dice.