# Flesh Shaper

Tags: Touch, Utility
Cost: #, St 2
Effect: You alter the body of another creature with the aid of runes. By spending 10 minutes writing runes on yourself or others, you can grant a creature one of the benefits listed below. Each creature can only have 1 rune alteration and the rune’s used for the change are visible somewhere on the body (can be hidden with clothing). This effect lasts for up to 1 hour or until the runes are removed.
Wings: Change the creatures arms to resemble wings. The creature is able to glide 1 tile for every 2 tiles it would fall. This effect does not work if it is hindered in any way (Stunned, Burning, Grappled, ext.)
Gills/Fins: Change the creature to be better in the water. The creature can breath underwater without needing air, and it can swim it’s Speed.
Change Appearance: Physically alter the creatures body to look like another’s. You can change sex, height, race, and appearance. This does not change the creatures Race Trait.