# Bless

Tags: Touch, Utility
Cost: #, St 1
Effect: Touch an Object or Creature. If cast on water it becomes Holy Water. If cast on a Creature they cannot be Cursed for 1 hour. If cast on a weapon the weapon does an extra 1 damage to Undead. Can be cast on a dead body to prevent it from being resurrected as an Undead.