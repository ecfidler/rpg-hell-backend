# Butter Fingers

Tags: Attack, CC, Ranged
Cost: Attack, St 2
Effect: Make a Soul Attack against a target within Range 6. On hit, until the end of your next turn, the target cannot use their hands to manipulate or grasp objects or surfaces and fails any checks made to do so. In addition they drop any items they are holding.