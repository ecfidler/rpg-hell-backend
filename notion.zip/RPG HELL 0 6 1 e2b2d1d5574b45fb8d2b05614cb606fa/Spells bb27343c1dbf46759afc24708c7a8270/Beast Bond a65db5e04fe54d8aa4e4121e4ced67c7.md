# Beast Bond

Tags: Attack, Ranged, Utility
Cost: Contest, St 1
Effect: Make a Nature Contest against a beast creature within 4 tiles of you. On Success the beast becomes friendly to you and neutral to any creature that hasn't harmed it. You can use your dice to control the beast.
This effect lasts until you harm the beast, you cast this spell again, dismiss the spell, or the beast dies. When the spell ends the beast will react based on how you treated it.