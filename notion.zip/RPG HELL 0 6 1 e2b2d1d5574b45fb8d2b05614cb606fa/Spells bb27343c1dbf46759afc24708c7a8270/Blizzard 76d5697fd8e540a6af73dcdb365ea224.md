# Blizzard

Tags: AOE, CC, Damage, Focus, Ranged
Cost: ###, St 4
Effect: You Focus on creating a localized Blizzard. Burst 2 centered on a target within 8 tiles. All targets within this area must make a Body Roll against the 3 dice given when casting. On failure, targets take 3 Damage and get 2 Stun and are Webbed in ice until your next turn. On success, creatures get 1 Stun and have half their Speed when Moving. Additionally, remove all Burn from creatures within the area.
You can spend additional dice on following turns to move the Blizzard 8 tiles in any direction.
The Blizzard goes away after 3 turns if you dispel it, you cast another Focused spell, or you take damage.