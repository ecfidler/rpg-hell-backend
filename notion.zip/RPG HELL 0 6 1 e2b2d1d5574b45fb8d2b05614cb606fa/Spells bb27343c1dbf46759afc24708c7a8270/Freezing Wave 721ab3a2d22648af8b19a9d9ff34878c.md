# Freezing Wave

Tags: AOE, CC
Cost: ###, St 2
Effect: Breath a Cone of ice outward Range 3. Freeze all liquids within this area. All targets within this area must make a Body Roll against the 3 dice given when casting. On failure, give the Creature Stun 2. Wet targets get Frozen until the start of your next turn. On success, give the Creature Stun 1. Remove all Burn from creatures within the area.