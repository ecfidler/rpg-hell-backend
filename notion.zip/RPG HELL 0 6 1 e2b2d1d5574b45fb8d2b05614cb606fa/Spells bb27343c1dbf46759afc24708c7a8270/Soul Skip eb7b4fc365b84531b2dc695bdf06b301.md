# Soul Skip

Tags: Ranged, Utility
Cost: #, St 2
Effect: Teleport to a location that you can see up to your Speed away.