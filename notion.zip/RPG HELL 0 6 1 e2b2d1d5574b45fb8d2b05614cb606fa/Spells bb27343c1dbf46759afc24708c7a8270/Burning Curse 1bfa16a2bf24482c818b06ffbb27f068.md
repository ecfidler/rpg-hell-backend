# Burning Curse

Tags: CC, Ranged
Cost: ###, St 5
Effect: Target a Creature or Object within range 6. The target must make a Soul Roll against the 3 dice given when casting. If they fail, give the target the following Curse. The curse does not go away until dispelled by Purge (must beat the number next to the curse) or the target dies. If this targets an object, the curse can affect anyone who touches the object.
Cursed Flames (6,5): The creature nolonger looses stacks of Burn. However, they cannot be killed by Burn or Fire spells. They still take damage from the Burn. If the creature survives 1 year with this curse they become a Burned Soul (See Creatures).