# Spectral Parachute

Tags: Ranged, Utility
Cost: #, St 1
Effect: You and up to 4 other creatures within Range 6 slow your falling to 4 tiles a round. While this is up you cannot take fall damage.
This effect lasts for 6 rounds, or until dispelled.