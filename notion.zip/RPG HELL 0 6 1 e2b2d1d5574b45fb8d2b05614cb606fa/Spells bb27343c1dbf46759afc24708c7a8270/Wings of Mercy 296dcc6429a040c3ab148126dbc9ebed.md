# Wings of Mercy

Tags: Ranged, Utility
Cost: #, St 4
Effect: Teleport to a Creature that is on Deaths Door, that you can see up to twice your Speed away. Heal the target for half of your Medicine rounded up.