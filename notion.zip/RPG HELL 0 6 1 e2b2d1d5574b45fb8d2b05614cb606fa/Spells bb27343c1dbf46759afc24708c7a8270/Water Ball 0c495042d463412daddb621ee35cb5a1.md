# Water Ball

Tags: Attack, CC, Utility
Cost: Attack, St 1
Effect: Create a waterball about 1 ft in diameter. You can then make a Soul Attack against a target within Range 8. On hit the target gets knocked back 4 tiles and any fires or Burning that were on them are put out.