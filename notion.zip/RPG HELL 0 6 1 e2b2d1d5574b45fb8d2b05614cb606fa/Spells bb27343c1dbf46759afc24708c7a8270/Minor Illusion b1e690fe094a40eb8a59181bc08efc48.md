# Minor Illusion

Tags: Focus, Ranged, Utility
Cost: Contest, St 0
Effect: Focus on creating an Illusion of your choice that is no larger in size than 1 foot square. Range 6. A creature can make a Core Roll against you to discern if it is an illusion.
The illusion lasts for 3 turns, until dispelled, you cast another Focused spell, or you take damage. You can spend an additional dice on the following turns to animate the illusion, resetting the number of turns until it dispels.