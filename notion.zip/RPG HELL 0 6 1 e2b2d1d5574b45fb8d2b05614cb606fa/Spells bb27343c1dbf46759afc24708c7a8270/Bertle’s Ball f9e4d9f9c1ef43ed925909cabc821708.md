# Bertle’s Ball

Tags: Focus, Touch, Utility
Cost: #, St 0
Effect: You Focus on creating a small ball, no bigger than your palm. The ball glows slightly giving it a faint outline through walls, allowing you to always see the ball, even through walls. (This lets you cast spells that require line of sight in places you cant see.)