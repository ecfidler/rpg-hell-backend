# Lightning Strike

Tags: Attack, Damage, Ranged
Cost: Attack, St 3
Effect: Make a Soul Attack against a target within Range 8. You may add 1 to one of the dice spent casting this spell if the target is wearing metal. On hit the target takes 5 damage. Deals an extra damage to Constructs and wet Creatures.