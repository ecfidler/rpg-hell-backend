# Fireball

Tags: AOE, Damage, Ranged
Cost: ###, St 3
Effect: Burst 2 centered on a target within 8 tiles. All targets within this area must make a Mind Roll against the 3 dice given when casting. On failure, gives 3 Burn. On success, gives 1 Burn.