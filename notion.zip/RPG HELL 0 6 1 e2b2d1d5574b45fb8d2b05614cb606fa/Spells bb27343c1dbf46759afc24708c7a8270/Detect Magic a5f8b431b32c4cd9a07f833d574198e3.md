# Detect Magic

Tags: Focus, Utility
Cost: #, St 2
Effect: You Focus on the waves of Soul around you. Objects/Creatures affected by magic glow a purple color.
This effect lasts for 6 turns, until dispelled, you cast another Focused spell, or you take damage.