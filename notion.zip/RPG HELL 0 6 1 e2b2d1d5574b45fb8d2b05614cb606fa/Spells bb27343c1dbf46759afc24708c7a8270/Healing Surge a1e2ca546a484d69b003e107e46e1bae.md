# Healing Surge

Tags: Ranged, Utility
Cost: ###, St 5
Effect: Target any number of Creatures you can see within 8 tiles. You cannot target undead or constructs. You may heal for up to twice your Medicine divided among the creatures targeted.