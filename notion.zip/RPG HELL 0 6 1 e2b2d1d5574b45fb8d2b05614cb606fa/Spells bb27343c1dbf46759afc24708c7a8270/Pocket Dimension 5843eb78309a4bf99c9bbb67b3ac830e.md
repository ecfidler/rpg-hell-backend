# Pocket Dimension

Tags: Touch, Utility
Cost: #, St 0
Effect: Create a small hole in space from a container. The space is 1 tile square of empty space. Every time you cast this spell it connects to the same space regardless of container. Only you can access this space, and if you die its contents are lost. This effect lasts for 3 turns.