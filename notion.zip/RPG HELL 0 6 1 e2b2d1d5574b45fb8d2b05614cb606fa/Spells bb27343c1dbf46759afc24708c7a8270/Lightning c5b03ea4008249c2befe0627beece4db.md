# Lightning

Tags: AOE, Damage, Ranged
Cost: ###, St 2
Effect: Range 6, make a Ray to a point within range. All targets within this area must make a Mind Roll against the 3 dice given when casting. On failure, deal 3 damage. On success, deal 1 damage. Deals an extra damage to Constructs and wet Creatures.