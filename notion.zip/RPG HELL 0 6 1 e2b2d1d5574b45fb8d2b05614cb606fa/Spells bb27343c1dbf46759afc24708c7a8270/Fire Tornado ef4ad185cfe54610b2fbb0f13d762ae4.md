# Fire Tornado

Tags: AOE, Attack, Damage, Focus, Ranged
Cost: ###, St 4
Effect: You Focus on creating a Flaming Tornado. Burst 2 centered on a target within 8 tiles. All targets within this area must make a Mind Roll against the 3 dice given when casting. On failure, targets take 2 Damage and gain Burn 3. On success, they gain Burn 2.
You can spend additional dice on following turns to move the Tornado 8 tiles in any direction.
The Tornado goes away after 3 turns if you dispel it, you cast another Focused spell, or you take damage.