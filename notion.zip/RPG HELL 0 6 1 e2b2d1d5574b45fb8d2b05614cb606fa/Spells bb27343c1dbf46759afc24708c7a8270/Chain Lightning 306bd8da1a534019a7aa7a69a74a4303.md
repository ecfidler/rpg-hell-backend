# Chain Lightning

Tags: Attack, Damage, Ranged
Cost: ##, St 4
Effect: Pick a target within Range 6. Make a Soul Attack against that target. If you hit, pick another target within Range 4 of that Target. You can do this up to 3 times. On hit, deals 3 damage. Deals an extra damage to Constructs and wet Creatures.