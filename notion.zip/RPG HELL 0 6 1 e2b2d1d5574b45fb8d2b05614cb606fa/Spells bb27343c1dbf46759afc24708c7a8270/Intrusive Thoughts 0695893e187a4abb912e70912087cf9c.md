# Intrusive Thoughts

Tags: CC, Ranged, Utility
Cost: Contest, St 2
Effect: Do a contested Soul roll against a creature within range 6. On success, you can implant a thought into the target’s mind. They believe the thought was their own and have no memory of the magic. On failure, they know you tried to cast magic on them but not what the spell was.