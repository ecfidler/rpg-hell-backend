# Counterspell

Cost: #, St 3
Effect: Spend your Locked dice to cast. You counter a spell that you can see within Range 6. This can be cast on the enemy’s turn.