# Invisibility

Tags: Focus, Utility
Cost: #, St 2
Effect: You Focus on giving a Creature Invisibility for 6 turns. The Invisibility goes away early if the creature does an action, you dispel the Invisibility, you cast another Focused spell, or you take damage. You can increase the number of targeted Creatures by gaining 1 extra Soul Strain per creature.