# Kinetic Toss

Tags: Attack, CC, Utility
Cost: Attack, St 4
Effect: Target a Creature or Object within range 6. Roll a Soul Attack against the target. On success telekineticly throw the target 6 tiles in any direction. If you throw a medium or larger Object into a creature, both targets take an amount of damage equal to how much movement was unused.