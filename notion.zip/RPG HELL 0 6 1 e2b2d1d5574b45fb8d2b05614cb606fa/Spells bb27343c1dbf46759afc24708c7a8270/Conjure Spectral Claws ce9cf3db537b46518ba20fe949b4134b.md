# Conjure Spectral Claws

Tags: Attack, Damage, Focus, Touch
Cost: Attack, St 2
Effect: Focus on conjuring a set of Spectral Claws (See weapons). These claws do damage based on your Soul. On cast you can do an Attack.
The claws go away after 6 turns, if you dispel it, you cast another Focused spell, or you take damage.