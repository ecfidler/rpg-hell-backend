# Death's Whisper

Tags: Damage, Ranged
Cost: #, St 5
Effect: Target a Creature within Range 8. If the target has 2 or less health set their Health to 0, this cannot be blocked with Ward.