# Control Elements

Tags: Touch, Utility
Cost: #, St 0
Effect: You can change the general shape and temperature of Earth, Air, Fire, and Water up to a maximum of 1 cubic tile. 
Some examples are being able to freeze water, ignite or snuff out small fires, dry wet objects or creatures, make air pockets in water, and remove grime from surfaces.