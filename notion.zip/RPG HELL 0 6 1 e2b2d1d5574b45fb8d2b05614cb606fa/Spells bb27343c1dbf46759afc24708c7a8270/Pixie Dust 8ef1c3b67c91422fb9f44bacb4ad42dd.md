# Pixie Dust

Tags: CC, Ranged
Cost: ###, St 1
Effect: Put creatures into a magical slumber. Target a number of Creatures you can see within 8 tiles who’s combined Health total is up to or less than 12. You cannot target undead or constructs. These creatures are forcefully put to sleep for 3 turns. These creatures wake up if another creature spends 1 dice to wake them or they take damage.