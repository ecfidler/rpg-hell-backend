# Fire breath

Tags: AOE, CC
Cost: ###, St 2
Effect: Breath a Cone of flame outward Range 3. Ignite all flammable objects within this area. All targets within this area must make a Mind Roll against the 3 dice given when casting. On failure, give the Creature Burn 2.  On success, give the Creature Burn 1. Wet Creatures are no longer wet and get 1 less Burn.