# Summon Beast

Tags: Focus, Touch, Utility
Cost: #, St 3
Effect: You Focus on summoning an Animal of DR 1 or lower. You can control it using your dice, otherwise it does not do any action. You can increase the DR of the summoned creature by spending 2 more Soul Strain for each level.
The creature goes away after 1 hour, if you dispel it, you cast another Focused spell, the creature dies, or you take damage.