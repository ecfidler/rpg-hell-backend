# Quick Repair

Tags: Touch, Utility
Cost: #, St 1
Effect: Touch a broken item or Construct. Repair the target for half of your Crafting rounded up. This can repair Shredded Armor up to half your Crafting rounded up per cast.