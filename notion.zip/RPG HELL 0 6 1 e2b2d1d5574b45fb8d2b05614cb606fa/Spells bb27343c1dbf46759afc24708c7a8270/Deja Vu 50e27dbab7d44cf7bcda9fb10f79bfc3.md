# Deja Vu

Tags: Ranged, Utility
Cost: Contest, St 4
Effect: Do a contested Mind roll against a creature within range 6. On success, you make the creature forget the last 5 minutes. They believe the thought was their own and have no memory of the magic. On failure, they know you tried to cast magic on them but not what the spell was.