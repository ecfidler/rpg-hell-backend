# Detonate

Tags: AOE, Damage, Ranged
Cost: ###, St 4
Effect: Target Creature you can see looses all stacks of Burning. Burst 2 centered on that creature.  All targets within this area must make a Mind Roll against the 3 dice given when casting. On failure, creatures take an amount of damage equal to the Burn stacks lost. On success, deals half as much damage.