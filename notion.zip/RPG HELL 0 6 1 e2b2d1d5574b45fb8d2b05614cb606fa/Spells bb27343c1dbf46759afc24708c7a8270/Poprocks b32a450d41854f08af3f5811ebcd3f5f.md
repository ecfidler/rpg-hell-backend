# Poprocks

Tags: Attack, CC, Ranged, Utility
Cost: Attack, St 0
Effect: Turn a rock into a little explosive. Make a Soul Attack against a target within Throw Range 6. On hit push the creature back (Knockback) an amount equal to half your current Soul Strain (rounded up) plus 1.