# Soul Grenade

Tags: AOE, Damage, Ranged
Cost: ###, St 1
Effect: Burst 1 centered on a target within 8 tiles. All targets within this area take 1 damage.