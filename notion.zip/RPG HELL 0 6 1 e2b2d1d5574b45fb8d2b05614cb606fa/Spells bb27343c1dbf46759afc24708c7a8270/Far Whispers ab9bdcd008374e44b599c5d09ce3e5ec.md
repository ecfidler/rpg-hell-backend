# Far Whispers

Tags: Ranged, Utility
Cost: #, St 0
Effect: Target a Creature you can see. Whisper a message no longer than 10 seconds long. The target, and only your target, will hear your whisper regardless of distance.