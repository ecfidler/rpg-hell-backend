# Phantom Fishing Rod

Tags: Attack, Ranged, Utility
Cost: Attack, St 0
Effect: Target a creature within Range 6. Pull a light object to you or if you target a large object or creature make a Soul Attack. On hit pull the target 3 tiles to you.