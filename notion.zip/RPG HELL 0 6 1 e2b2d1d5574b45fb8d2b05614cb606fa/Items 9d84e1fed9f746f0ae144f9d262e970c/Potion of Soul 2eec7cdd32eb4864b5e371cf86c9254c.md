# Potion of Soul

Tags: Consumable, Non-Magic, Potion, Tiny
Effect: Gain 1 Soul. This effect goes away after 3 turns (30 sec).