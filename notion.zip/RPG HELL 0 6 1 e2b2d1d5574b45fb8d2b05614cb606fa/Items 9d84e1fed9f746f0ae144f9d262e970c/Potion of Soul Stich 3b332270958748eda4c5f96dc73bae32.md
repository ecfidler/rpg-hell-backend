# Potion of Soul Stich

Tags: Consumable, Non-Magic, Potion, Tiny
Effect: Cleans 3.