# Potion of Mind

Tags: Consumable, Non-Magic, Potion, Tiny
Effect: Gain 1 Mind for 30 seconds (3 turns).