# Potion of Life

Tags: Consumable, Magic, Medicine, Potion, Tiny
Effect: Revive a dead creature. The creature’s Soul must be free and the creature cannot have been dead for more than 1 month.
Requires a Phoenix Feather, Undying Heart, and Holy Water to craft.