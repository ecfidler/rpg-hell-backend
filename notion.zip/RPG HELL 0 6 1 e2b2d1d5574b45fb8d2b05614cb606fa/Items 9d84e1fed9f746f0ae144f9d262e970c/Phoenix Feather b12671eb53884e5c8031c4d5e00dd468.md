# Phoenix Feather

Tags: Consumable, Magic, Medicine, Tiny
Effect: A golden orange feather that is warm to the touch.
If a Creature dies while in possession of the feather the feather turns to dust, the creature's Health is set to 1, and they are no longer on Death's Door.
This is needed to craft a Potion of Life.