# Bandage

Tags: Consumable, Medicine, Non-Magic, Tiny
Effect: Target a Creature, cannot target undead or constructs. Heal the target 2 Health + Half your Medicine Rounded up. 
Can be crafted with Medicine or Crafting Rolls.