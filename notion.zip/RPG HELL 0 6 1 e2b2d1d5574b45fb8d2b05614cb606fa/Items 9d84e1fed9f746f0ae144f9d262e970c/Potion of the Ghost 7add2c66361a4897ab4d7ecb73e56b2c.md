# Potion of the Ghost

Tags: Consumable, Non-Magic, Potion, Tiny
Effect: Gain Intangible for 60 seconds (6 turns).