# Potion of Body

Tags: Consumable, Non-Magic, Potion, Tiny
Effect: Gain 1 Body for 30 seconds (3 turns).