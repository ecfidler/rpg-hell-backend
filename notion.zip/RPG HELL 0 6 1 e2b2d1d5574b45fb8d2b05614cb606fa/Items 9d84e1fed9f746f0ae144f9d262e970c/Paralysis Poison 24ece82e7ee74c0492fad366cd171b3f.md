# Paralysis Poison

Tags: Consumable, Non-Magic, Potion, Tiny
Effect: When ingested or put into the blood (coated blade) roll Body. You must get a (5,4,4) or be Frozen for 20 seconds (2 turns).