# Frag Grenade

Tags: Consumable, Non-Magic, Tiny
Effect: Throw Range 6. Burst 1 centered wherever it lands. Make a Core Attack roll against all creatures within the area. Deals 1 damage.