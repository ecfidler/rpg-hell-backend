# Holy Water

Tags: Consumable, Non-Magic, Potion, Tiny
Effect: Deals 1 damage to Undead when in contact (this does not remove the Holy water). This is needed to craft a Potion of Life.