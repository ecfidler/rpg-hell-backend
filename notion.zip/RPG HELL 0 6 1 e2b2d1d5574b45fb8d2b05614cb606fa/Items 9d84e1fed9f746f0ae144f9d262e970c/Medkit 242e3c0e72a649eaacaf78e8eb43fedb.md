# Medkit

Tags: Consumable, Medicine, Non-Magic, Small
Effect: Target a Creature, cannot target undead or constructs. Heal the target for your Medicine + Level.
Can be crafted with Medicine or Crafting Rolls.