# Undying Heart

Tags: Consumable, Magic, Medicine, Tiny
Effect: A heart that continues to beat even when its body is lost.
Can be Consumed to permanently increase Health by 2.
This is needed to craft a Potion of Life.