# Healing Spray

Tags: Consumable, Medicine, Non-Magic, Tiny
Effect: Requires Medicine 3 to be used properly. Target a Creature, cannot target undead or constructs. Heal the target 2 + Level Health. 
Can be crafted with Medicine or Crafting Rolls.