# Potion of StoneSkin

Tags: Consumable, Non-Magic, Potion, Tiny
Effect: Gain -1 Damage when Hit for 30 seconds (3 turns).