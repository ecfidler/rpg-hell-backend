# Potion of Flight

Tags: Consumable, Non-Magic, Potion, Tiny
Effect: Gain Flight (Can move its Speed in the air) for 60 seconds (6 turns).