# Royal Meal

Tags: Consumable, Non-Magic, Tiny
Effect: Kings and Emperors eat this. The best meal money can buy.