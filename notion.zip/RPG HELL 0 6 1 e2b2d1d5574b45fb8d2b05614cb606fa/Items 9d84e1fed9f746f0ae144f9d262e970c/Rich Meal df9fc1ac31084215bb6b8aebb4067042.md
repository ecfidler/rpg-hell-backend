# Rich Meal

Tags: Consumable, Non-Magic, Tiny
Effect: An expensive meal made for the wealthy. Most will find this tasty.