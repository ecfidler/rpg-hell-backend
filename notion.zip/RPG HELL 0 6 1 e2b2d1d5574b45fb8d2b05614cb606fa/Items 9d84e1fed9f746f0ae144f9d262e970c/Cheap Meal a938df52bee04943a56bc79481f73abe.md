# Cheap Meal

Tags: Consumable, Non-Magic, Tiny
Effect: A prepared meal. It's better than Travel Food but not by much.