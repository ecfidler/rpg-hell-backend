# Decent Meal

Tags: Consumable, Non-Magic, Tiny
Effect: A well prepared meal. Most will find this acceptable.