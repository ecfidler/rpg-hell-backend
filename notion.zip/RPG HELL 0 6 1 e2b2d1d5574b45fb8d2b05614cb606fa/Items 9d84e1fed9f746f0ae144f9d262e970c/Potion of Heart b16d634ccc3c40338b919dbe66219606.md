# Potion of Heart

Tags: Consumable, Non-Magic, Potion, Tiny
Effect: Gain 4 Temporary Health. This goes away at the end of the next rest or when used.