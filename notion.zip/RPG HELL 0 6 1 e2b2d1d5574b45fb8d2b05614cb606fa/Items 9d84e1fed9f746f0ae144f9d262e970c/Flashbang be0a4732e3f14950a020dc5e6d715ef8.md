# Flashbang

Tags: Consumable, Non-Magic, Tiny
Effect: Throw Range 6. Cast Lightshow wherever it lands. Make a Core Attack roll for the attack instead of Soul.