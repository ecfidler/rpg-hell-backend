# Unarmored

Requirement: Core
Defense: >=3., >=4
Effect: +1 Speed
Traits: Defence 0, Speed 1