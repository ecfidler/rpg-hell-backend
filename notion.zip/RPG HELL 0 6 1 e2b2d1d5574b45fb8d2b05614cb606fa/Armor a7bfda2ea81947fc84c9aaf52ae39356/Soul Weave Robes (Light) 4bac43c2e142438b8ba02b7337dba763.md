# Soul Weave Robes (Light)

Requirement: Soul 6
Defense: >=3., >=5
Effect: Armor 1, Ward 2
Traits: Armor 1, Defence 1, Ward 2