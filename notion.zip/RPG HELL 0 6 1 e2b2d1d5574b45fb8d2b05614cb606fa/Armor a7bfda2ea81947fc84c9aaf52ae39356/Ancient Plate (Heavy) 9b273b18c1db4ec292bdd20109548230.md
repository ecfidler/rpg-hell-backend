# Ancient Plate (Heavy)

Requirement: Body 6
Defense: >=4, >=5
Effect: -2 Speed, Armor 4
Traits: Armor 4, Defence 3, nSpeed 2