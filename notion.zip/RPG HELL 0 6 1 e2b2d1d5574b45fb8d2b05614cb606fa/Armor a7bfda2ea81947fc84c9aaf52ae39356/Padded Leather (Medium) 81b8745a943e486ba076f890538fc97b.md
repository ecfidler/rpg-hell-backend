# Padded Leather (Medium)

Requirement: Mind 4
Defense: >=4, >=4.
Effect: Armor 1, Ward 1
Traits: Armor 1, Defence 2, Ward 1, nSpeed 1