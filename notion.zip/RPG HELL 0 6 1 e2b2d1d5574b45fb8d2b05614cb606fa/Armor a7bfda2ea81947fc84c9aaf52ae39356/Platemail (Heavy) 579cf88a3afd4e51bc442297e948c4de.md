# Platemail (Heavy)

Requirement: Body 4
Defense: >=4., >=5
Effect: -2 Speed, Armor 2
Traits: Armor 2, Defence 3, nSpeed 2