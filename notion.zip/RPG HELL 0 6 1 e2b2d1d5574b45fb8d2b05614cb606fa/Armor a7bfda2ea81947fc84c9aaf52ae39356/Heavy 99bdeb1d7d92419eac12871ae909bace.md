# Heavy

Requirement: Body 1
Defense: >=4., >=5
Effect: -2 Speed
Traits: Defence 3, nSpeed 2