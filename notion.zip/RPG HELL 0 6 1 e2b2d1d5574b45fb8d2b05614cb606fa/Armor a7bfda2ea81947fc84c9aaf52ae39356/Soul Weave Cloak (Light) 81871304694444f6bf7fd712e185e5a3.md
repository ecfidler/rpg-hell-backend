# Soul Weave Cloak (Light)

Requirement: Soul 4
Defense: >=3., >=5
Effect: Ward 2
Traits: Defence 1, Ward 2