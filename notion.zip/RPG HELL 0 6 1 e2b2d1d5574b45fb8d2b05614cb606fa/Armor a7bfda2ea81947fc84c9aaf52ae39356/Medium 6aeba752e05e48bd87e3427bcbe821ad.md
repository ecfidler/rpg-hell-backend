# Medium

Requirement: Body 1
Defense: >=4, >=4.
Effect: -1 Speed
Traits: Defence 2, nSpeed 1