# Composite Chainmail (Medium)

Requirement: Mind 6
Defense: >=4, >=4.
Effect: Armor 2, Ward 1
Traits: Armor 2, Defence 2, Ward 1, nSpeed 1