# Basic Gameplay

# Basic Gameplay

## General Rules

      All players, creatures, and objects have a set of skills indicated by the number next to their respective field. When a player or the GM wants to accomplish something they roll two d6 (six sided dice) plus an additional dice for each point in the required Skill. The GM decides what the required value is deemed as a success, typically this is 4 or greater. To succeed they must meet or go over the required dice, which is set by the GM. Usually to succeed on a roll you need to get 1 or 2 successes. The more successes you get the better the outcome. 
For instance if you wanted to jump a gap you would roll 2d6 + Body (we will say its 2 for this example) and need to get at least one success to make the jump safely. 
For some actions the GM may request a roll of your **Core Stat**, see Stats for how to find this stat. For instance all basic attacks use the characters **Core Stat**.

     During combat you may **Lock** any unused dice at the end of your turn. Locking a die saves the value rolled. On subsequent turns you may expend a locked die to replace any rolled die value with its own. This is done before the results are announced and the die is expended even on a failure. For example: If you roll two 3s and have a locked dice of 5. You may use this 5 to replace a 3 possibly succeeding on the check. You may only have **One** Locked dice at a time and any new dice that get locked replace the current Locked dice.

### Contests

     All creatures or objects in the Contest roll a Stat or Skill dictated by the source of the Contest. The GM decides what the required value is deemed as a success, typically this is 4 or greater. Whichever party has more successes wins the contest. Ties are based on the higher physical rolls. If this tiebreaker results in a tie the player wins by default.
     In combat you spend two dice to incite contests. These spent dice have no impact on the contest roll, and are generally ignored after use.

### Combat Basics

     When the GM requests that combat begin the game becomes turn based. The turn order in combat is determined by Creatures **Speed**. The characters with the highest speed move first. On ties the GM may decide if the players or enemies get advantage and attack first if the situation allows it. 

     When your turn in combat comes up you get a number of dice equal to 3 + half your level rounded down (0 or 1=3, 2:3 = 4, 4:5 = 5, etc.). You can spend these dice to do specific actions. The basic actions that all creatures have are: **Weapon Attack, Spell Cast, Use an Item, Move, Hide, Search, Push, Grapple, Overwatch, Lock, Manipulate, and Meditate.** See Traits for more info.

      You get additional actions based on the Traits you take during level up or character creation. The cost for each is listed next to the trait. Attacks are dependent on the target’s armor. Contests are always two dice.

### Deaths Door

     When a player hits 0 or less life they go on Death’s Door. The next time the player is damaged and set to 0 or less life, while on Death’s Door, they roll a dice. On a 2 or less they Die. On a 3 or more they are left standing but the next time they would have to roll to survive a Death’s Door hit the they must roll 1 higher (≥4, then ≥5, then 6). If they are hit when they need to roll a 7 or higher they Die. This effect lasts until they die or are no longer on Death’s Door.

<aside>
🐢 For more challenge see Extra Challenge under GM Rulebook.

</aside>

### Resting

      A rest is considered any stretch of 8 or more hours where you do not take or deal damage. You do not need to sleep for this to take effect. This can only be done once per day. Completing a rest has the following benefits: You Heal to Full, lose any non permanent effects, refresh Abilities from Traits, and set your Soul Strain to 0.

### Magic

     **Magic** is a wondrous and mysterious thing. Creatures have an amount of **Soul Strain** which empowers or debilitates their magic casting. **You get an amount of Soul Strain equal to two times your Soul. Additionally you get an amount of spells equal to your Soul Strain**. **You can only take spells that have a Soul Strain cost of your Level plus 1 or lower.** On level up you are able to replace 2 spells of your choosing in addition to gaining new ones if you increase your Soul Strain
     There are a number of Spells. Every spell has A Soul Strain Cost associated with it. When you cast a spell you gain an amount of Soul Strain (Noted as SS from here on). Once you reach your max SS some spells will be empowered however it comes at a risk. You can take damage if you try to cast a spell while at max SS. You take an amount of damage equal to how far you go over your max SS when casting. For example if you are at max SS and cast the spell Waterball you take 1 damage. This damage cannot be reduced in any way.
     In Combat every spell has a dice cost associated with it. You use these dice to help cast the associated spells. Generally there are only 4 types of dice cost: Attack (same as weapon attacks), Contests (same as other contests, costs: 2 dice), Area spells (3 dice which are what are needed to save against), and utility or buff spells (1 dice). 

### Knockback and Fall Damage

     If you are knocked back into a wall, floor, or other hard surface you can take damage depending on how much knockback is unused. You take 1 damage for every 2 tiles you would be pushed back if you cannot be pushed back. For instance if you are up against a wall and a creature knocks you back 6 tiles you take 3 damage. This damage is calculated after initial impact such as from a Greathammer. (Ward 1 blocks Greathammer damage but not knockback damage. Ward 2 blocks both.)
      For fall damage you are able to fall 3 tiles without taking damage. If you fall from a height of 4 tiles or higher you take 1 damage per distance traveled after the first 3 (1 for 4, 2 for 5, ect).

# Stats, Skills, and Their Meanings

There are three primary Stats: Body, Mind, and Soul. Their descriptions are below. If a GM asks for a Core Roll, they are asking for the highest of these three stats.

## Body

Primarily used for things such as feats of strength, basic agility, holding your breath, ext.

## Mind

Primarily used for mental tasks, hacking, puzzles, types of history, ext.

## Soul

Primarily used for magic, religion, and art.

## Other Core Stats

**Health** is how much damage you can take before going on Death’s Door. (See Character Creation)

**Defense** is what dice an opponent needs to spend to damage you. (See Armor)

**Speed** is how fast you can move and when you take your turn in combat. It starts as 8. (See Armor)

## Sub-Skills

**Thieving** is used for lockpicking, pickpocketing, forgeries, and Stealth.

**Nature** is used for handling, foraging, or growing plants/animals.

**Crafting** is used for fixing, making objects, or creating/seeing traps. See Crafting for more info.

**Charm** is used for persuading, lying, or intimidating others.

**Arcana** is used when investigating magical items or runes and generally is for written magic.

**Medicine** is used for treating injuries on yourself or others.

# Character Creation

### Creating a Level 1 Character.

- First pick a Race Trait and Create a Background (optional), listed below.
- All Skills and Sub-Skills start at 0. Your **Speed** is defaulted to 8, and your **Health** is equal to          $2 + Level + (3*Body)+(2*Mind)+Soul$
- For level 1, starting level, you get 2 Core Stat increases which you can spend to increase your **Body**, **Mind**, or **Soul** by 1, to a maximum of 2.
- You also get 2 Sub-Skill increases which you can spend to increase your **Thieving**, **Nature**, **Crafting**, **Charm**, **Arcana**, or **Medicine**, to a maximum of 2.

<aside>
✨ Magic is based on Soul. You get 2 Soul Strain for every point into Soul.
Additionally, your number of known [✨Spells](Spells%20bb27343c1dbf46759afc24708c7a8270.md) is equal to your Soul Strain.
You cannot take a spell that has a Soul Strain higher than your Level +1.

</aside>

- You may pick 3 starting [♻Traits](Traits%2099fe6eaccb8d41e393f24aaed9a09fd1.md) for which you meet the requirements for.
- Lastly, you are able to take 2 [⚔Weapons](Weapons%208accb66afe7245ddac52c0c3db53fe84.md) and an [🐌Armor](Armor%20a7bfda2ea81947fc84c9aaf52ae39356.md) of your choice that you meet the requirements for. A Bandage, 15 coins, and a Non-magical Item of your choice.

<aside>
💡 **If you become stuck when creating a character we have provided a handy chart to give you ideas as to what each Skill/Sub-skill pairing might look like. See charts below.**

</aside>

### Leveling up!

     For every level after the first you gain an additional **Core Skill** increase and a **Sub-Skill** increase. You cannot increase a Core Skill or Sub-Skill higher than 6.

Additionally you can pick another **Trait** that you meet the requirements for, and you may exchange a previous chosen **Trait** for another one that you meet the requirements for.

<aside>
💡 **Don't forget to update your health!**

</aside>

<aside>
✨ You are able to replace 2 spells you know with 2 others. This does not include adding new spells due to increasing your Soul Strain.

</aside>

### Useful Level Table

| Level | Increases | Traits | Dice |
| --- | --- | --- | --- |
| 1 | 2 | 3 | 3 |
| 2 | 3 | 4 | 4 |
| 3 | 4 | 5 | 4 |
| 4 | 5 | 6 | 5 |
| 5 | 6 | 7 | 5 |
| 6 | 7 | 8 | 6 |
| 7 | 8 | 9 | 6 |
| 8 | 9 | 10 | 7 |
| 9 | 10 | 11 | 7 |

## Example Character Types

| Primary -> | Body | Mind | Soul |
| --- | --- | --- | --- |
| Body | Fighter | Skirmisher | Spellsword |
| Mind | Warlord | Tactician | Diviner |
| Soul | Paladin | Psionic | Mage |

| Primary -> | Body | Mind | Soul |
| --- | --- | --- | --- |
| Thieving | Thug/Ruffian | Rogue | Spellthief |
| Nature | Warden | Ranger | Druid / Elementalist |
| Crafting | Blacksmith | Steampunker | Artificer |
| Charm | Gladiator | Charlatan | Enchanter / Warlock |
| Arcana | Runeblade | Alchemist | Lore master |
| Medicine | Battlemedic | Doctor | Healer / Blood magic |

## Quick Character Sheet

```markdown
Body: 0, Mind: 0, Soul: 0
Armor _,  Health _/_, Speed 8. 
Locked [], Dice: _

Crafting: 0, Thieving: 0, Charm: 0, Nature: 0, Arcana: 0, Medicine: 0
Soul Strain - 0/_

**Traits:**

**Spells:**

**Items:**
Coin - 15
Bandage - Target a Creature, cannot target undead or constructs. Heal the target 2 Health + Half your Medicine Rounded up.
Light Armor - 2 Dice
Dagger - Body - 1 Damage. Throw Range 6
```

## Race Traits

Every race is unique and can look however you wish. Just because you picked Draconic does not mean you need to look like a dragon.

<aside>
❓ You can roll two dice to randomly pick one. Pick one dice to be the first (E is for even, O is for odd), pick another to be the second (1-6).

</aside>

| Rolls | Race Type | Bonus Trait |
| --- | --- | --- |
| O,1 | Human | Pick an extra Skill that doesn't require more than 1 in a base skill (Body, Mind, Soul), you must still meet it’s requirement. |
| O,2 | Aquatic | You can breath underwater without needing air, and you can swim your Speed. |
| O,3 | Avian | You are able to glide 2 tile for every 1 tiles you fall. This effect does not work if you are hindered in any way (Stunned, Burning, Grappled, ext.) |
| O,4 | Beastkin | Increase your Speed by 1. |
| O,5 | Constructed | You gain the Creature type; Construct in addition to Humanoid. Gain 1 Armor. |
| O,6 | Draconic | Pick a type: Fire, Ice, Earth, or Lightning.
Fire: You can cast Fire Breath once per Rest without gaining Soul Strain. 
Ice: You can cast Freezing Wave once per Rest without gaining Soul Strain.
Earth: You can cast Bolder Toss once per Rest without gaining Soul Strain.
Lightning: You can cast Lightning once per Rest without gaining Soul Strain.
You use your Core Skill instead of Soul when casting this spell. |
| E,1 | Elemental | Gain the Spell Control Elements. |
| E,2 | Hellborn | After taking damage from Burn reduce it by 2 instead of 1, and you reduce the time you are Frozen by 1 when you first become Frozen. |
| E,3 | Nymph Born | Gain Nature Speak for free. |
| E,4 | Seeker | Gain Dreams of the Future for free, and at Level 3 gain Past and Future for free. |
| E,5 | Undergrounder | Darkness does not scare you. You can cast Glow at will, and Fog Light once per Rest. |
| E,6 | Mutant | You gain the Creature type; Monstrosity in addition to Humanoid. You cannot be Feared or Charmed. |

# Advanced Character Customization

## Background

Backgrounds are only for roleplay and to help give motives for the character. They have no direct effect in combat. 

<aside>
💡 Below is some examples for types of background you could have, and what effects they might have in roleplay. You do not need to pick from the following backgrounds from this list, you could make up your own with your GM.

</aside>

<aside>
❓ The core of your characters backstory, you can roll a dice to randomly pick one.

</aside>

| Roll | Background Base | Possible roleplay effects. |
| --- | --- | --- |
| 1 | Peasant | You have been poor since you where born, which has made you do some rather unsavory acts. You have some friendly connections in your local underground. |
| 2 | Commoner | A simple farmer or craftsman. You know your local homeland well, better than most others. |
| 3 | Trader | You have traded in goods and have meet some strange people. You have at least 1 business connection everywhere you have been. |
| 4 | Noble | You are born, or perhaps made into nobility. You have a noble title and are recognized for it. |
| 5 | Soldier/Guard | You have protected your land, possibly even been to war. You have a military title and know all the local laws. |
| 6 | Sailor | Fishing and the open sea have been your life. You know your way around ports and ships as if it was home. |

Why you left home to be here and possibly your motivation.

| Roll | Reason for Leaving Home | Description |
| --- | --- | --- |
| 1 | Traveler | You never liked staying in one spot, rather living on the open road was always your preference. |
| 2 | Catastrophe | Some disaster befell your home, and you no-longer had a reason to stay. |
| 3 | Fortune or Glory | A quiet life for you was no life at all. You want to make a name for yourself and home couldn't give that to you. |
| 4 | A Job or Task | Someone or something gave you a job, and you must complete it. |
| 5 | Exile | You have done something and have been banished from your home. |
| 6 | Hunted | You have done something and where forced to flee. Otherwise risking death or imprisonment.  |

## Power Sources

The source of a characters power can add new depth or variance to a character’s backstory or gameplay. Below are several options to diversify your character.

<aside>
💡 These options do not have restrictions for how they are chosen and are up to the player and game master on how to implement them. For example, character who chooses “Dark Magic” as their power source but is building Body as their main stat is not necessarily a mage, but maybe entered into a pact with a Hag to gain power.

</aside>

| Roll | Power Source | Description |
| --- | --- | --- |
| 1 | Muse | Artist; perhaps passion devoted to an artform. Uses a form of art as an implementation for their abilities. Ie: a Bard conveying tactical information through song. A Blade Dancer elegantly dancing through a swordfight, or a Painter drawing illusions to life. |
| 2 | Dark Magic | Blessings of power; usually given by dark forces and usually for some price. Some examples could be a hag giving enhanced strength, in exchange for bringing back something, or a demon giving a part of their magic in exchange for someone's soul. |
| 3 | Wild Magic | People affected by a chaotic curse… or possibly a blessing gone awry. When you roll snake eyes (two 1’s) something unexpected happens. GM has a table. |
| 4 | Divinity | All things holy; A priest utters a prayer of healing. A Paladin Imbues his blade with glowing light as he charges. An inquisitor tracks down the meeting place of a cult through guidance provided by his deity. |
| 5 | Trainee/Novice | A person training to become powerful or great though their own power. |
| 6 | Ancestry | Your Ancestors had great power, and it was passed on to you. |