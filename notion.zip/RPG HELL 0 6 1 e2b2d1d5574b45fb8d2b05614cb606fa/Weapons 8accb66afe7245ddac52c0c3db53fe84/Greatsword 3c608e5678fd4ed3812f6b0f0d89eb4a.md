# Greatsword

Requirement: Body 2
Tags: 3 Damage, Two Handed