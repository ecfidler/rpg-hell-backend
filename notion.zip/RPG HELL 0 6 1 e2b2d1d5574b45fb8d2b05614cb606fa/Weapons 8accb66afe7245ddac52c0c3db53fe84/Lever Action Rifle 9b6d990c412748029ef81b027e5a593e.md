# Lever Action Rifle

Requirement: Mind 4
Tags: 3 Damage, Armor Piercing, Loading, Range 12, Two Handed