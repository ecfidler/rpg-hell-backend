# Seeking Thistles

Requirement: Mind 2, Soul
Tags: 2 Damage, Returning, Throw Range 6