# Steamthrower

Requirement: Special
Effect: Goes through targets until the end of its range.
Tags: 2 Damage, Burn 1, Loading, Range 6, Two Handed