# Soul Lanturn

Requirement: Soul
Tags: 1 Damage, Glow 2