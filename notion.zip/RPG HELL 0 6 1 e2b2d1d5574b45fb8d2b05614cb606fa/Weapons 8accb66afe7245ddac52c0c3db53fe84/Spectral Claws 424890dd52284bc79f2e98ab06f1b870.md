# Spectral Claws

Requirement: Soul, Special
Effect: Does an Your Soul in damage.
Tags: Armor Shredding, Two Handed