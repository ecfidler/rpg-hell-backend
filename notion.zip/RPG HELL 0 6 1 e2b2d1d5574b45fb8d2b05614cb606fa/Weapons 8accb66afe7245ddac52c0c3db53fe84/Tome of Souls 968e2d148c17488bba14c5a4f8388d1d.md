# Tome of Souls

Requirement: Mind, Soul 2
Effect: Gain an additional 2 Soul Strain
Tags: 1 Damage, Range 6