# Ancient Blade

Requirement: Body 4
Tags: 4 Damage