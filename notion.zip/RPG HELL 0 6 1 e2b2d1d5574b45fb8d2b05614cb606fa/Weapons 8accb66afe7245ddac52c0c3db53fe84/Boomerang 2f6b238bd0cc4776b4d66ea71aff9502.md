# Boomerang

Requirement: Core
Tags: 1 Damage, Returning, Throw Range 8