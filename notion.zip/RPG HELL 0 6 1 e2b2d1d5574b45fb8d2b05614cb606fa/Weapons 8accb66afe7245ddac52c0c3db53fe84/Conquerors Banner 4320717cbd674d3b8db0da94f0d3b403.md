# Conquerors Banner

Requirement: Body 2, Mind
Effect: Friendly creatures that are within 2 tiles of the Banner gain 1 Temporary Health at the start of their Turn. 
Tags: 2 Damage, Two Handed