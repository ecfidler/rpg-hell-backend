# Soul Lantern Staff

Requirement: Soul 2
Tags: 1 Damage, Glow 2, Range 6