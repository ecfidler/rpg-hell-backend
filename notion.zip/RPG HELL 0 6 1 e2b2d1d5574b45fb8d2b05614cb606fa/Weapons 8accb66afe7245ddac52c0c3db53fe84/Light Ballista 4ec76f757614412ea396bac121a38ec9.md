# Light Ballista

Requirement: Body, Mind 2
Tags: 3 Damage, Armor Piercing, Knockback 2, Loading, Range 10, Two Handed