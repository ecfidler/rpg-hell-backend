# Ancient Spear

Requirement: Body 6
Tags: 4 Damage, Armor Piercing, Throw Range 8