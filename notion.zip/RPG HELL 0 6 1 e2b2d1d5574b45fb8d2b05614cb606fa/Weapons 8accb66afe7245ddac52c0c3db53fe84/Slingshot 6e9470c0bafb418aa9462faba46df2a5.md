# Slingshot

Requirement: Core
Effect: Increases the Throw Range of small items by 2.
Tags: 1 Damage, Range 10