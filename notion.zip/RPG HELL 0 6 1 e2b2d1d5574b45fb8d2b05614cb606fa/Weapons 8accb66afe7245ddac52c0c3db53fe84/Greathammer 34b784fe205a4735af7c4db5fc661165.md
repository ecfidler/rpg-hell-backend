# Greathammer

Requirement: Body 2
Tags: 2 Damage, Knockback 2, Two Handed