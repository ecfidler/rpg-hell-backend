# Flintlock Pistol

Requirement: Core
Tags: 1 Damage, Armor Shredding, Loading, Range 10