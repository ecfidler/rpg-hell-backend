# Clockwork Cannon

Requirement: Special
Tags: 2 Damage, Armor Shredding, Knockback 6, Loading, Range 10, Two Handed