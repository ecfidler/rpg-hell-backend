# Flintlock Rifle

Requirement: Mind
Tags: 2 Damage, Loading, Range 12, Two Handed