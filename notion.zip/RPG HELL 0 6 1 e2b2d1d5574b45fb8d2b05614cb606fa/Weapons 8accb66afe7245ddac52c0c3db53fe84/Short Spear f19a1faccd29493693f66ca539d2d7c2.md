# Short Spear

Requirement: Core 2
Tags: 1 Damage, Armor Piercing, Throw Range 6