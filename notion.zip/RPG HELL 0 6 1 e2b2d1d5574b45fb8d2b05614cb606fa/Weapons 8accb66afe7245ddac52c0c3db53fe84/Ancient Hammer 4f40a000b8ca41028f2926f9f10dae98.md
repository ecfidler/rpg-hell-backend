# Ancient Hammer

Requirement: Body 6
Tags: 5 Damage, Knockback 2, Two Handed