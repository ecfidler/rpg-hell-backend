# Bronze Bolter

Requirement: Special
Effect: Each attack fires two bolts (all hits hit twice)
Tags: 1 Damage, Range 12