# Ancient Long Rifle

Requirement: Mind 6
Tags: 4 Damage, Armor Piercing, Loading, Range 12, Two Handed