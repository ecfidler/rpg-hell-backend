# Ancient Carbine

Requirement: Mind 6
Tags: 4 Damage, Range 10, Two Handed