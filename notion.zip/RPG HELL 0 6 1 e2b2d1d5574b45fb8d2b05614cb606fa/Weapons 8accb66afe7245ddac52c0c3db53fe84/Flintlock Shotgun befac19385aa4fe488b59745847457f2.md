# Flintlock Shotgun

Requirement: Mind 2
Tags: 2 Damage, Armor Shredding, Knockback 2, Loading, Range 6, Two Handed