# Trap Maker

Requirements: Crafting 1
Dice Cost: ##
Effect: Make one of 3 traps listed below. Each trap costs 5 gold to craft, and covers 1 tile or item. Traps can be reclaimed if unused. Tripwire: A small hidden wire which will knock over any creature that steps on it. Can trigger non magical items. Snare: A loop of rope that when triggered Grapples and lifts its prey 2 tiles up. Popmine: A plate that when activated knocks its prey 3 tiles in a direction. The direction is decided during the trap's creation.