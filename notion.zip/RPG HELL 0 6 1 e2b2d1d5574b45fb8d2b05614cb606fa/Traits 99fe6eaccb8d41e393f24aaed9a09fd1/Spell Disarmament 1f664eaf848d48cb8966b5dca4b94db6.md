# Spell Disarmament

Requirements: Soul 1, Thieving 3
Dice Cost: ##
Effect: You can cast Dispel Magic with Thieves’ tools without gaining Soul Strain.