# Death’s Reaper

Requirements: Body 6
Dice Cost: Attack, P
Effect: When you kill a creature with a Melee Attack. Gain an additional Dice.