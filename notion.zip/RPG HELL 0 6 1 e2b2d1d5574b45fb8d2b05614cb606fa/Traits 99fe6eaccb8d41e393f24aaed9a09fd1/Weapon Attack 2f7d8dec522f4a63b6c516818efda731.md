# Weapon Attack

Requirements: Base
Dice Cost: ##
Effect: Use your weapon to hit a target. To hit a target you must give 2 dice. Then when doing damage removing damage from the target based on its Armor and Ward.