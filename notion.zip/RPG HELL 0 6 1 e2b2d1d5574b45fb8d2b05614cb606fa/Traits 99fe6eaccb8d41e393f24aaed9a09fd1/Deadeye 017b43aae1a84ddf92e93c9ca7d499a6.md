# Deadeye

Requirements: Mind 2
Dice Cost: 11+#
Effect: Hit a target with a Ranged Attack. This cannot be used more than once in a turn. This can be taken multiple times to increase the number of times you can do this in a turn.