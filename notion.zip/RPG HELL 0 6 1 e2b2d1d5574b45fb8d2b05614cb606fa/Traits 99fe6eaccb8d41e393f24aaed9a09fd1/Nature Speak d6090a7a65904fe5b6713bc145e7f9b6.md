# Nature Speak

Requirements: Nature 1
Dice Cost: P
Effect: You can have simple conversations with animals, and can use Nature instead of Charm when talking to them.