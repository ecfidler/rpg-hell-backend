# Backstab

Requirements: Thieving 3
Dice Cost: Attack+#
Effect: Do a Melee Attack, it does an extra 1 Damage. The Attack gains Armor Penetration if it does not already have it. You can only do this once per turn. This can be taken multiple times to increase the bonus damage by 1 each time this is taken.