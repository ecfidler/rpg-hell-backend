# Telekinetic Mind

Requirements: Mind 4, Soul 2
Dice Cost: #, Contest
Effect: You learn the spells Telekinesis, Phantom Fishing Rod, and Poprocks if you don't already know them. Additionally, you can cast Telekinesis for only 1 Soul Strain instead of 3.