# Powerful Smites

Requirements: Body 2, Soul 1
Dice Cost: Attack, P
Effect: When you cast Smite, increase its damage by half your Soul rounded up.