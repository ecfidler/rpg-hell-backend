# Death’s Knock

Requirements: Body 2, Mind 1
Dice Cost: Attack, P
Effect: While on Death’s Door you do an extra 2 damage from Weapon Attacks.