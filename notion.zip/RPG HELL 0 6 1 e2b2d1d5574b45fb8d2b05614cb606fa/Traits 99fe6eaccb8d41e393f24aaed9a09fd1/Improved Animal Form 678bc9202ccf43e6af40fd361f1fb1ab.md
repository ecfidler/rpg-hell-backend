# Improved Animal Form

Requirements: Nature 5, Soul 2
Dice Cost: P
Effect: When you Transform through the use of the Animal Form Trait you can gain half of the Creature’s Health as Temporary Health. You can do this once per Rest. The Temporary Health does not go away if you transform back into your normal self.