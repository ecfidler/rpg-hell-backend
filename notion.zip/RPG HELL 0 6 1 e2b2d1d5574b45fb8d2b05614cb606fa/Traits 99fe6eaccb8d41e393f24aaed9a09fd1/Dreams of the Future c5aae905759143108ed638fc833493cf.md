# Dreams of the Future

Requirements: Soul 1
Dice Cost: P
Effect: At the end of a Rest roll a number of dice equal to your Level and Lock one of the dice.