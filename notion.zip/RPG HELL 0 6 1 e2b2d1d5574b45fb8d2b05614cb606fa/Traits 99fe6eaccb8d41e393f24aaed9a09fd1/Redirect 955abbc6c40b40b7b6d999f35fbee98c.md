# Redirect

Requirements: Mind 1, Thieving 3
Dice Cost: #, P
Effect: When you get hit spend your Locked dice to redirect the attack to a creature within 1 tile of you. You cannot do this if there are no creatures within 1 tile of you.