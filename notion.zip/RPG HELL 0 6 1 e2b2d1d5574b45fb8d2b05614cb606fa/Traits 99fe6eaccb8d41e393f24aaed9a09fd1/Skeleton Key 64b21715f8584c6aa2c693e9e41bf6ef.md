# Skeleton Key

Requirements: Thieving 1
Dice Cost: P
Effect: You can lockpick without needing tools. Additionally, you roll an extra dice when you lockpick with tools.