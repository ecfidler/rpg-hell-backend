# Improved Healer

Requirements: Medicine 3, Mind 1
Dice Cost: P
Effect: When you use a Bandage use your full Medicine roll instead of half.