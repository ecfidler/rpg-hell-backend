# Improvised Weapon

Requirements: Crafting 1
Dice Cost: #
Effect: You can quickly make an improvised weapon. Spend 10 gold and pick a Core weapon, the improvised weapon has the stats of that weapon. It breaks after 4 uses loosing all gold spent in the process.