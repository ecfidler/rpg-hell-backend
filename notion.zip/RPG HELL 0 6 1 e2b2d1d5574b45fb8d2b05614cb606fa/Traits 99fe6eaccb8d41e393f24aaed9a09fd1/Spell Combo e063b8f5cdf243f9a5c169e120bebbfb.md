# Spell Combo

Requirements: Body 6, Soul 4
Dice Cost: Attack+#
Effect: Cast a Damaging Melee Spell. After hitting with this Melee Spell, take the lowest die spent on the spell and the other given die to make a Melee Weapon Attack. This cannot be done more than once per turn.