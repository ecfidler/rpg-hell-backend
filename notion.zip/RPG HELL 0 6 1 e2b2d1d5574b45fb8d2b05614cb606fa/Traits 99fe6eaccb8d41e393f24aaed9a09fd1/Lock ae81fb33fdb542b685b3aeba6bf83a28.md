# Lock

Requirements: Base
Dice Cost: #, P
Effect: You may Lock any unused dice at the end of your Turn.