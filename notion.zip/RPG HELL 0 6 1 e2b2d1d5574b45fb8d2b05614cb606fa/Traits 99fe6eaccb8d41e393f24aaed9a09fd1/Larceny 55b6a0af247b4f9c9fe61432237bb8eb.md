# Larceny

Requirements: Body 2, Thieving 5
Dice Cost: Contest
Effect: Roll a contested Body Check against a target within 1 tile of you. On success you wrestle an item away from the target.