# Silent Scaling

Requirements: Thieving 3
Dice Cost: P
Effect: You make no noise while climbing or falling up to half your Speed.