# Ventriloquism

Requirements: Charm 3, Soul 1
Dice Cost: Contest
Effect: Do a contested Soul roll against a creature within range 6. On success you make the target recites a sentence as well as it can and in the same tone. They believe the sentence was their own and have no memory of the magic. On failure they someone tried to cast magic on them but not what it was or who cast it.