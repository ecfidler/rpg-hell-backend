# Resuscitate

Requirements: Medicine 5, Mind 2
Dice Cost: ##
Effect: Touch a creature. You Reduce the target’s Death’s Door Count to go back to a 2 or less. Additionally, heal the creature as if you used a Medkit.