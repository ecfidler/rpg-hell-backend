# Frostbite

Requirements: Nature 3, Soul 1
Dice Cost: P
Effect: When you effect a creature with Stun, Frozen, or effects that reduce movement, deal 1 damage to them.