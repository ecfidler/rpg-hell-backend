# Soul Bind

Requirements: Body 1, Soul 2
Dice Cost: Attack, P
Effect: You bind an object or weapon to your very soul. The object gains Returning and if it's a weapon you can do Soul Attack Roll instead of its default Stat attack roll. You must still meet the minimum requirements to use the weapon.