# Natures Friend

Requirements: Nature 3
Dice Cost: Attack, P
Effect: You can cast Beast Bond without gaining Soul Strain.