# Protected

Requirements: Body 4, Soul 2
Dice Cost: P
Effect: When you are put on Death’s Door, gain 2 stacks of Ward.