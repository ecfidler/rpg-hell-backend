# Combo Finisher

Requirements: Body 4, Mind 2
Dice Cost: ##
Effect: If you hit the same creature twice this turn you can do another Weapon Attack.