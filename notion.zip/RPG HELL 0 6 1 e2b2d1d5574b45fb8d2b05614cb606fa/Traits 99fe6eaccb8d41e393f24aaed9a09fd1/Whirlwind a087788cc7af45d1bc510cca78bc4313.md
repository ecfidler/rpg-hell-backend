# Whirlwind

Requirements: Body 2
Dice Cost: Attack
Effect: Do a Melee Attack against all creatures within 1 tile of you. You can only do this once per turn.