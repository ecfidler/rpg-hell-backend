# Tunneler

Requirements: Body 1, Crafting 3
Dice Cost: ##
Effect: You can remove a number of tiles equal to your crafting stat. Different types of tiles cost more or less to dig through 
(Cost : Tiles removed). 
Soft (1:1), such as dirt or loose stones
Dence (2:1), such as stone walls
Reinforced (3:1), such as metal walls or solid stone