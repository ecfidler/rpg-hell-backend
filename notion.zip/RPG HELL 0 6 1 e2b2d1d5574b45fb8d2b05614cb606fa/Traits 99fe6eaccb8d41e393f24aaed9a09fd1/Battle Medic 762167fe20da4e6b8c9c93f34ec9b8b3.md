# Battle Medic

Requirements: Medicine 1
Dice Cost: P
Effect: You gain 4 Speed when moving to an ally who has 2 or less health. 
This can be taken multiple times to increase the Speed by 3 each time this is taken.