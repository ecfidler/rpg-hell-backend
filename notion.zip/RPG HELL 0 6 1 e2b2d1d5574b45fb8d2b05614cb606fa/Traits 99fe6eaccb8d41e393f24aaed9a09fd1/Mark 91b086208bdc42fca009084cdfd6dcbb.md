# Mark

Requirements: Mind 1
Dice Cost: #
Effect: Mark a target for 3 turns. (Marked Targets cant become hidden and loose 1 Armor if they have Armor) [Marking an already Marked Target has no effect except to reset the duration of Marked]