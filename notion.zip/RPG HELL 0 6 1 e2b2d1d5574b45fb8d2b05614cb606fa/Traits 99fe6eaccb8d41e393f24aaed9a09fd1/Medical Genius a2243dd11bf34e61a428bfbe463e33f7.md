# Medical Genius

Requirements: Medicine 5, Mind 2
Dice Cost: P
Effect: When you use a Medkit on a creature they gain all the benefits of a Rest except for fully healing. (Medkit healing is still the same)