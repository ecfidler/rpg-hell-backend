# Climber

Requirements: Body 2
Dice Cost: #
Effect: Can move your Speed up vertical walls without needing to roll or spending extra Speed.