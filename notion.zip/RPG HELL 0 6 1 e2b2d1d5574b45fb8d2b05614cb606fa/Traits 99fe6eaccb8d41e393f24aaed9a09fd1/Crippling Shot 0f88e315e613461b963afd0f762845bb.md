# Crippling Shot

Requirements: Mind 2
Dice Cost: Attack+#
Effect: Do a Ranged Attack, on hit, reduce the target’s Speed by 2.