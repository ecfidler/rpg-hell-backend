# Intrusive Soul

Requirements: Charm 5, Soul 2
Dice Cost: Contest, P
Effect: You can cast Intrusive Thoughts without gaining Soul Strain. Additionally you can use Charm instead of Soul when using the save.