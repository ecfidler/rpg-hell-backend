# Pushing Strike

Requirements: Body 2
Dice Cost: Attack+#
Effect: Do a Melee Attack it has an additional 3 Knockback.