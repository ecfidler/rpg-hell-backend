# Silencing Strike

Requirements: Soul 1, Thieving 3
Dice Cost: Attack+#
Effect: Make a Weapon Attack. Until the end of the target’s next turn they are unable to cast spells.