# Change of Thinking

Requirements: Mind 4
Dice Cost: #
Effect: Set a dice to 4. You can do this once per turn.