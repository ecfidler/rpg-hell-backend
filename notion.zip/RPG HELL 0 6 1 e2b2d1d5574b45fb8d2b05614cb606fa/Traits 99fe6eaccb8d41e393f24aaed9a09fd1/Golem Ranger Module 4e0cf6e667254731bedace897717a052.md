# Golem Ranger Module

Requirements: Crafting 5, Soul 2
Dice Cost: P
Effect: Your Golem’s Soul Weapon gets +4 range and gains Armor Piercing. Additionally, it’s Armor Becomes Light