# Blade Wave

Requirements: Arcana 5, Body 2
Dice Cost: Attack
Effect: You can Expel runic magic to create a wave of runic energy. Suppress the magic of one of your active runes to deal your Melee Weapons damage to all creatures in a 8 tile line. While suppressed the rune has no effect. This suppression lasts for 10 minutes.