# Reactive Explosions

Requirements: Soul 4
Dice Cost: P
Effect: When you do an area of effect spell, you can set one of the required dice to 5 (You still spend 3 dice, you just change 1 dice).