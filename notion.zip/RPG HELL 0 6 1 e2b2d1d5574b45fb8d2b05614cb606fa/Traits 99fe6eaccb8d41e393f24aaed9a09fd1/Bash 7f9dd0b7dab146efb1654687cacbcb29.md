# Bash

Requirements: Body 2
Dice Cost: Attack
Effect: Stun 3.