# Thorny Armor

Requirements: Body 1, Nature 3
Dice Cost: #, P
Effect: You may spend your Locked dice to do Nature (Rounded down) to a creature that has hit you with a Melee attack.