# Past and Future

Requirements: Mind 1, Soul 2
Dice Cost: #
Effect: You can now Lock two dice. When you would Lock a dice while having two Locked you may pick which Locked dice to replace.