# Runic Augmentation

Requirements: Arcana 5, Body 2
Dice Cost: #
Effect: You gain the ability to alter bodies with the aid of runes. By spending 10 minutes writing runes on yourself or others, you can grant a creature one of the benefits listed below. Each creature can only have 1 rune alteration and the rune’s used for the change are visible somewhere on the body (can be hidden with clothing). 
Wings: 
Gills/Fins: 
Change Appearance: