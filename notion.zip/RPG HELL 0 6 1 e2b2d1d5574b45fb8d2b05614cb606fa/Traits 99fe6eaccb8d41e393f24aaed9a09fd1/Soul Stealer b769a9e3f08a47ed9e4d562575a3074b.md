# Soul Stealer

Requirements: Body 2, Soul 4
Dice Cost: Attack, P
Effect: When you kill an enemy with a non-spell Melee Attack, Cleanse 2.