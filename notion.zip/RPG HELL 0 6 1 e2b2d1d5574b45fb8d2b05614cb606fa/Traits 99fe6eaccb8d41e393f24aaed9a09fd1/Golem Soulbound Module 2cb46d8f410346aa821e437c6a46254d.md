# Golem Soulbound Module

Requirements: Arcana 5, Soul 2
Dice Cost: P
Effect: Your Golem gains the spell Swapper with a St cost of 1, however it only can target the Owner (you).
The Owner (you) can cast spells through the golem as if they (you) where the golem