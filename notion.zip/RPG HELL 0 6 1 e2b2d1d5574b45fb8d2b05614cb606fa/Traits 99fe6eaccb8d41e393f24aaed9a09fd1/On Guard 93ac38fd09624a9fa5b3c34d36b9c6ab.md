# On Guard

Requirements: Mind 1
Dice Cost: Attack, P
Effect: If you end your turn without Attacking/Damaging anything. Go on Overwatch for free.