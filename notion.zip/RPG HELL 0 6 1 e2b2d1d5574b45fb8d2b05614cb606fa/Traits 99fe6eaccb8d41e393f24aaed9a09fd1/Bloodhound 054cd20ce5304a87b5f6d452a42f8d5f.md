# Bloodhound

Requirements: Body 1
Dice Cost: P
Effect: Gain 3 extra Speed when moving to a Marked creature.
This can be taken multiple times to increase the Speed by 2 each time this is taken.