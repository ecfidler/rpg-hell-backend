# Command

Requirements: Mind 2
Dice Cost: #, ##
Effect: Give an ally the ability to attack (2 dice) or move (1 dice). You cannot use this ability more than once per turn.