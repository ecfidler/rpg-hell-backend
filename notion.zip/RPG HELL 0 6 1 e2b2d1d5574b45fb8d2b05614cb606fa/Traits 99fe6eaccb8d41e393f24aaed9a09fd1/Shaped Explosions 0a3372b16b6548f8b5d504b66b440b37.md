# Shaped Explosions

Requirements: Soul 4
Dice Cost: ####
Effect: Cast an area of effect spell. When you do, you can choose up to 3 creatures within the area. Those creatures succeed on the save without needing to roll.