# Combative Runing

Requirements: Arcana 3, Body 1
Dice Cost: P
Effect: You have figured out how to improve the flow of runic magic through your tools. Weapons you wield and armor you wear can have an additional rune inserted into it. Additionally, Craft a rune. This rune must be put in your weapon or armor.