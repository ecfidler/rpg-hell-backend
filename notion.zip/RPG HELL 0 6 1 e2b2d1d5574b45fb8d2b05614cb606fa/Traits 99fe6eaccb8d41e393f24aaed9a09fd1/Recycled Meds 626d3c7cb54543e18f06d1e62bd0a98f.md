# Recycled Meds

Requirements: Medicine 3, Mind 1
Dice Cost: P
Effect: You no-longer use up Bandages and can use a Medkit twice before it is expent.