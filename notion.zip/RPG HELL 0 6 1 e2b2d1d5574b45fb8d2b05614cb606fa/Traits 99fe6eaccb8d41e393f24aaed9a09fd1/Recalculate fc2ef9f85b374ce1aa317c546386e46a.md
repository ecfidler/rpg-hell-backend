# Recalculate

Requirements: Mind 4
Dice Cost: #
Effect: You may flip this dice to show its opposite face. (1⇔6, 2⇔5, 3⇔4) You can only do this once per turn. This can be done outside of Combat for checks.