# Positive Influence

Requirements: Charm 5, Soul 2
Dice Cost: P
Effect: When you cast a spell on an ally then their next dice roll is increased by 1. This does not go off on a 6.