# Blessed/Cursed Caster

Requirements: Body 2, Soul 1
Dice Cost: P
Effect: You have been gifted with power. You can cast Bless or Weak Curse using 1 Soul Strain instead of 2, and all spells you cast do an extra 1 damage to Undead.