# Natures Bind

Requirements: Body 1, Nature 3
Dice Cost: Contest, P
Effect: You can Grapple someone using earth or plants within 4 tiles of you instead of having touch. All other rules still apply to the Grapple.