# Crystalize Soul

Requirements: Nature 3, Soul 1
Dice Cost: P
Effect: Whenever you gain Soul Strain from the result of casting a spell. Gain 1 Armor for every 2 Soul Strain gained. This effect goes away the next time you are hit or after 10 minutes.