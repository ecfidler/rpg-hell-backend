# Simple Golem

Requirements: Arcana 3, Soul 1
Dice Cost: #, ##, P
Effect: You can create a Personal Golem (See Creatures). You can control any number of Constructs with your dice, but they must all be given the same Command.