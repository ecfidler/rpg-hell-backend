# Strangle Hold

Requirements: Body 1, Thieving 3
Dice Cost: P
Effect: While you have a creature Grappled. They cannot cast spells or speak.