# Soul Shielded

Requirements: Soul 6
Dice Cost: P
Effect: You can have a maximum of 4 Ward instead of 3. Additionally, gain an additional Ward on Rest.