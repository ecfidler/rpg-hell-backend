# Spell Copying

Requirements: Soul 1, Thieving 3
Dice Cost: P
Effect: If you see a spell being cast by someone else, you temporarily know that spell for 60 seconds (6 turns) regardless of if you know the spell innately.