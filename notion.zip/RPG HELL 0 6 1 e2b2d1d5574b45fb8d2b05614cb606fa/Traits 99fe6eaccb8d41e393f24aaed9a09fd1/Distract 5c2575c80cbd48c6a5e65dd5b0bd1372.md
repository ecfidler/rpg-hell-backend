# Distract

Requirements: Charm 3, Mind 1
Dice Cost: Contest
Effect: Make a distraction within Range 6. Make a Contested Charm roll against a creature you can see. On success the creature cannot willingly move away from the distraction and must spend a dice to move closer if possible.