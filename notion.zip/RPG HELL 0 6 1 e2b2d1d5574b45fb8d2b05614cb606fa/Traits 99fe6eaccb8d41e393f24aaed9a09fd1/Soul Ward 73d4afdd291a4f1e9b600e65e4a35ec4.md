# Soul Ward

Requirements: Soul 2
Dice Cost: P
Effect: When you take damage you can gain Ward 1, and gain 2 Soul Strain, then take the damage. This effect cannot happen if you are at max Ward.