# Enhanced Motivate

Requirements: Mind 4
Dice Cost: P
Effect: When you use Motivate, increase the dice’s value by 1. This effect doesn’t apply if the dice is already 6.