# Mental Mage

Requirements: Mind 1
Dice Cost: P
Effect: If your Max Soul Strain is 0 it becomes 2. If it is higher, increase it by 1.