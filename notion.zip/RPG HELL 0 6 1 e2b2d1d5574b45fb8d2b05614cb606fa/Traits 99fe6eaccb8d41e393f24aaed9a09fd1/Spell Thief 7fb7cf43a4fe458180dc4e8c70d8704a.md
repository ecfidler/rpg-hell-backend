# Spell Thief

Requirements: Soul 2, Thieving 5
Dice Cost: Contest, P
Effect: If you successfully Counterspell a Spell. You can Cast that spell for half its Soul Strain cost (rounded up) on your next turn.