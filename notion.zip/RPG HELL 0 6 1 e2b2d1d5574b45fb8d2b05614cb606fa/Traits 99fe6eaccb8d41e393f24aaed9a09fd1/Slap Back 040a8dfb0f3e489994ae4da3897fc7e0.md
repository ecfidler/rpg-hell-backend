# Slap Back

Requirements: Body 1, Thieving 3
Dice Cost: #
Effect: Spend your locked dice when using this trait. Make a Melee attack on a creature who has hit you with a Melee attack.