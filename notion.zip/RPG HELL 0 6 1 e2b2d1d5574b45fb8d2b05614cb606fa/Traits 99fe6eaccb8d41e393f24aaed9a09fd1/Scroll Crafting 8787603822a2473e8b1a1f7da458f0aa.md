# Scroll Crafting

Requirements: Arcana 3, Soul 1
Dice Cost: P
Effect: You can create a magical scroll. This scroll can contain any Spell you know when crafting, and can be used by anyone with Magic (St). The person using the scroll can cast the spell on the scroll for half its St cost if they know the spell or at full cost if they don't. You can only have 1 scroll written at a time, if another one is written the first one loses its power.