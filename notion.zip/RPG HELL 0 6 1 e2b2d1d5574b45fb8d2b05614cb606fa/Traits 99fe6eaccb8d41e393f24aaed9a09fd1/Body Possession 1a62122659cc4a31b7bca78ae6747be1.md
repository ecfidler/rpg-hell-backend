# Body Possession

Requirements: Soul 2, Thieving 5
Dice Cost: ###
Effect: You can take over another humanoids living body for up to 10 minutes. The effected creature must be unconscious and will wake up if it takes damage. At the end of the effect, if you choose to leave the body, or if the creature wakes up from damage, you are booted to the nearest safe tile next to the creature. You cannot enter the same creature for 1 day after using this effect on them.