# In the Shadows

Requirements: Mind 1, Thieving 3
Dice Cost: Attack, P
Effect: When you kill a creature while hidden you do not become revealed.