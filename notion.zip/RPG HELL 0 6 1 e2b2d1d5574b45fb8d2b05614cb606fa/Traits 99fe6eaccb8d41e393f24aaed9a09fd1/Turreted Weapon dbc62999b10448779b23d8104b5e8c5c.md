# Turreted Weapon

Requirements: Crafting 3, Mind 1
Dice Cost: #, Attack
Effect: You can turn one of your weapons into a semi automated Turret. If the Turret is destroyed the weapon drops and is broken. The weapon can be picked up by you and returns to being a normal weapon.
You can control any number of Constructs with your dice, but they must all be given the same Command.