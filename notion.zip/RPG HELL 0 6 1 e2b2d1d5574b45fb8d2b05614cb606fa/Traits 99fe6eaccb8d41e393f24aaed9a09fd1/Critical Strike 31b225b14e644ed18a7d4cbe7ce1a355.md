# Critical Strike

Requirements: Body 4
Dice Cost: Attack
Effect: Do a Melee Attack. Roll a dice on a 6 it does Double damage. Otherwise it does normal damage. This can only be done once per turn.