# Steam Weapons

Requirements: Crafting 3, Mind 1
Dice Cost: P
Effect: You can create 1 of 3 specialty weapons.
The Bronze Bolter; a repeating crossbow, the Steamthrower: a steam based Flamethrower, or the Clockwork Cannon; a large blunderbuss that shoots scrap. See Weapons for more info.