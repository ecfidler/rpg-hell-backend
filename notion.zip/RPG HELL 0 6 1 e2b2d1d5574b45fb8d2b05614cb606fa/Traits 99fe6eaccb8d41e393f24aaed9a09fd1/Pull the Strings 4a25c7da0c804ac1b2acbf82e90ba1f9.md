# Pull the Strings

Requirements: Charm 5, Mind 2
Dice Cost: Attack
Effect: Choose a creature within range, They immediately make a weapon attack against another creature of your choice within their weapon range. They use the dice given for this attack.