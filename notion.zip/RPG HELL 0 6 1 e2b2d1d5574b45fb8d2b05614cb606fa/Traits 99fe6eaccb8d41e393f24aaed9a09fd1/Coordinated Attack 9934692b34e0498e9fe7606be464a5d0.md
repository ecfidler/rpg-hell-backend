# Coordinated Attack

Requirements: Mind 4
Dice Cost: Attack+#
Effect: Make a Weapon Attack aginst a single target. An ally within 1 tile of the target may spend their locked dice and the bonus dice spent on this trait to make an attack against the same target.