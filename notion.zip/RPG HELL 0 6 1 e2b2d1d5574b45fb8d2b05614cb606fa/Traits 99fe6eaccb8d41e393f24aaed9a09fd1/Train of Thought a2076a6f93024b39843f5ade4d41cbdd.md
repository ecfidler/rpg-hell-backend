# Train of Thought

Requirements: Mind 4
Dice Cost: P
Effect: If you don't have a locked die at the end of your turn lock a 3.