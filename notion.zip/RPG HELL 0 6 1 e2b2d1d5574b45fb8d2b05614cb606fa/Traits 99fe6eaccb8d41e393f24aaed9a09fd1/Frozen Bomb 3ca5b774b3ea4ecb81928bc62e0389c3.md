# Frozen Bomb

Requirements: Nature 5, Soul 2
Dice Cost: ###
Effect: Target up to 3 Creatures you can see. Those targets loose all stacks of Stun, and Frozen. Burst 1 centered on those creatures.  All creatures within this area creatures take an amount of damage equal to the Stun stacks lost.