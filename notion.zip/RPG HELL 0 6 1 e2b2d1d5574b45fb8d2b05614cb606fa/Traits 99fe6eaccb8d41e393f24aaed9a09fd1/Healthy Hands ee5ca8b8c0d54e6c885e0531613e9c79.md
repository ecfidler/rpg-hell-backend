# Healthy Hands

Requirements: Medicine 3, Soul 1
Dice Cost: P
Effect: When you cast the Healing Hands Spell use your full Medicine roll instead of half.