# Corrupted Ancient Guard Golem

Tags: Construct
DR: 3

```markdown
**Corrupted Ancient Guard Golem** Lvl 3
Body: 3, Mind: 1, Soul: 0
Armor Heavy,  Health 16/16, Speed 6.

Crafting: 2, Thieving: 0, Charm: 0, Nature: 0, Arcana: 1, Medicine: 0
Soul Strain - 0/0

**Traits:**
Combat Blade- Attack - 3 Damage.
Whirlwind - Attack - Do a Melee Attack against all creatures within 1 tile of you. You can only do this once per turn.
Simple Launcher - Attack - 2 Dmg, Range 6
Mark - # - Mark a target for 3 turns.

Bloodhound - Gain 3 extra Speed when moving to a Marked creature.
Defender - When you use Overwatch and you hit a creature. That creature’s Speed is set to 0 and gets Webbed this turn.
Hackable - (6,4) - Roll Mind/Theiving. Can be hacked if the score is higher than the Hackable value.
Construct - Does not require food, water, or air to function.

**Spells:**

**Items:**
Scrap Metal - 1d6 lb

**Notes:**
```