# Ice Oni

Tags: Planar
DR: 7

```markdown
**Ice Oni** Lvl 7
Body: 7, Mind: 0, Soul: 1
Armor Heavy,  Health 31/31, Speed 6.

Crafting: 0, Thieving: 2, Charm: 5, Nature: 0, Arcana: 0, Medicine: 0
Soul Strain - 0/2

**Traits:**
Great Club - Attack - 5 Damage. Knockback 2
Frozen Grasp - Attack - 3 Damage, Stun 2.
Whirlwind - Attack - Do a Melee Attack against all creatures within 1 tile of you. You can only do this once per turn.
Ghost - # - Go Incorporeal until your next turn.
Humanoid Shapeshift - ## - Disguize yourself as a humanoid.

Unnatural Regeneration - Heal 5 at the start of your turn if your not Burning
Planar Regeneration - Cleans 1 Soul Strain at the start of your turn.
Large - Takes up 2x2 tiles. Increase Body by 1.

**Spells:**
1 SSt: Conjure Fog, Pixie Dust
2 SSt: Intrusive Thoughts
4 SSt: Blizzard

**Items:**
Coin - 15

**Notes:**
```