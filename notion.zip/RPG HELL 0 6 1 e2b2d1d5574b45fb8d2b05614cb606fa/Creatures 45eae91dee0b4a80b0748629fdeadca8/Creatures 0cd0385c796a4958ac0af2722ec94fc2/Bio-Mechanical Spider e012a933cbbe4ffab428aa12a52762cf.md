# Bio-Mechanical Spider

Tags: Construct, Monstrosity
DR: 4

```markdown
**Bio-Mechanical Spider** Lvl 4
Body: 3, Mind: 1, Soul: 0
Armor Medium,  Health 17/17, Speed 7.

Crafting: 3, Thieving: 0, Charm: 0, Nature: 0, Arcana: 1, Medicine: 0
Soul Strain - 0/2

**Traits:**
Bite - Attack - 3 Damage.
Web Sling - Contest (##) - Roll a Contested Body Check on a target within Range 4. On success the target gets Webbed.
Web Lay - # - Place a layer of webbing within Burst 1 of the spider.

Sticky Climber - Can scale vertical walls and ceilings without needing to roll.
Construct - Does not require food, water, or air to function.
Bio-Hackable - (6,4,4) - Roll Arcana. Can be hacked if the score is higher than the Hackable value.
Deathless - Can be revived with a Crafting score of 20 or higher (sum).
Forced Soul - Get 2 Soul Strain, do not get any spells

**Spells:**

**Items:**
Scrap Metal - 1d6 lb
Mystery Meat - 1d6 lb
Silk - 1d6 lb
Soul Core - Roll (1d6 on 5/6 it is unbroken)
```