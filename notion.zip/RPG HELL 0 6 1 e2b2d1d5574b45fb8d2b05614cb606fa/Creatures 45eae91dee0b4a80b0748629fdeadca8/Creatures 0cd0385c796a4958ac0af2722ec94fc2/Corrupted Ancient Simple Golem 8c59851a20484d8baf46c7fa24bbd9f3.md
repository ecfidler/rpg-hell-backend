# Corrupted Ancient Simple Golem

Tags: Construct
DR: 2

```markdown
**Corrupted Ancient Simple Golem** Lvl 2
Body: 1, Mind: 2, Soul: 0
Armor Medium,  Health 11/11, Speed 7.

Crafting: 2, Thieving: 0, Charm: 0, Nature: 0, Arcana: 1, Medicine: 0
Soul Strain - 0/0

**Traits:**
Claw - Attack - 1 Damage.
Simple Launcher - Attack - 2 Dmg, Range 6
Mark - # - Mark a target for 3 turns.
Crippling Shot - Attack+# - Do a Ranged Attack, on hit, reduce the target’s Speed by 2.

Hackable - (6,4) - Roll Mind/Theiving. Can be hacked if the score is higher than the Hackable value.
Construct - Does not require food, water, or air to function.

**Spells:**

**Items:**
Scrap Metal - 1d6 lb

**Notes:**
```