# Baby Dragon

Tags: Animal
DR: 4

```markdown
**Baby Dragon** Lvl 4
Body: 4, Mind: 0, Soul: 1
Armor Medium,  Health 19/19, Speed 8.

Crafting: 0, Thieving: 3, Charm: 0, Nature: 2, Arcana: 0, Medicine: 0
Soul Strain - 0/2

**Traits:**
Powerful Bite - Attack - 3 Damage.
Pick an Element for all powers below (Fire, Ice, Air, Earth)
Elemental Power - ### - Cast Fire breath (Fire), Ice Wave (Ice), Lightning (Air), or Boulder Toss (Earth) without gaining Soul Strain.

Flight - Can move its Speed in the air.
Fire Immune (Fire Only) - Cannot take damage from Fire or Burn.
Ice Immune (Ice Only) - Cannot become Frozen and reduce the amount of Stun by 1.
Fast Flyer (Air Only) - Gains 2 speed when Flying
Animal Tunneler (Earth Only) - Gain the Tunneler trait, it uses Nature instead of Crafting 

**Spells:**
SS 0 - **Control Elements (Primal Element only)**

**Items:**
Dragon Scales - 1d6 / 2 rounded down.

```