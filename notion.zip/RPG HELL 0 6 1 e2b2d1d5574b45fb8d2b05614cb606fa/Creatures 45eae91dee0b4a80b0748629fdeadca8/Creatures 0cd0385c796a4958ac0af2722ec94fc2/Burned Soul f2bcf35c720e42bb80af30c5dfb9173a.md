# Burned Soul

Tags: Undead
DR: 6

```markdown
**Burned Soul** Lvl 6
Body: 1, Mind: 0, Soul: 6
Armor Medium + Ward 2,  Health 17/17, Speed 8.

Crafting: 0, Thieving: 0, Charm: 0, Nature: 0, Arcana: 0, Medicine: 6
Soul Strain - 0/12

**Traits:**
Spectral Claws - Attack - 6 Damage. Armor Shreading
Ghost - # - Go Incorporeal until your next turn.

Flame Healing - The creature heals from Burn or Fire spells.
Cursed Flames - Curse (6,5) - The creature nolonger looses stacks of Burn. However, they cannot be killed by Burn or Fire spells.
Powerful Undead - Curse (6,5,4) - The creature is undead. When this creature hits 0 or less health they roll deaths door rolls. 

**Spells:**
2 SSt: Fire breath
4 SSt: Fire Tornado
5 SSt: Burning Curse

**Items:**
Ash - 2d6 lb

**Notes:**
```