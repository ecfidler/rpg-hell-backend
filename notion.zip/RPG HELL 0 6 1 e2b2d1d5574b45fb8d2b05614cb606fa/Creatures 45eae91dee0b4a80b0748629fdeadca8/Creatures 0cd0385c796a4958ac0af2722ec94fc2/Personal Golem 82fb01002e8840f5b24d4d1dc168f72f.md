# Personal Golem

Tags: Construct
DR: -1

```markdown
**Personal Golem** Lvl V
Body: C/2, Mind: A/2, Soul: 0
Armor Unarmored,  Health V/V, Speed 7.

Crafting: 0, Thieving: 0, Charm: 0, Nature: 0, Arcana: 0, Medicine: 0
Soul Strain - 0/2

**Traits:**
Soul Weapon - Attack - (C+A)/2 Damage. Range 6.
Telepathy - # - Bind your mind to a willing creature's mind. You can use your action on later turns to see/hear through their senses or send/receive simple messages. You can only be bound to one creature at a time.

Flight - Can move its Speed in the air.
Construct - Does not require food, water, or air to function.
Deathless - Can be revived with a Crafting score of 20 or higher (sum).
Forced Soul - Get 2 Soul Strain, do not get any spells

**Spells:**

**Items:**

**Notes:**
C stands for Creators Crafting Score, 
A stands for Creators Arcana Score,
V is Vareiable (HP = B+M+Lvl) [Lvl is Creators Level]
All #/2 are rounded down.

Ranger Module - From Trait (C) - Your Golem’s Soul Weapon gets +4 range and gains Armor Piercing. Additionally, it’s Armor Becomes Light 
Soulbound Module - From Trait (A) - It gains the spell Swapper with a St Cost of 1, however it only can target the Owner: The owner can cast spells through the golem as if they where the golem 
```