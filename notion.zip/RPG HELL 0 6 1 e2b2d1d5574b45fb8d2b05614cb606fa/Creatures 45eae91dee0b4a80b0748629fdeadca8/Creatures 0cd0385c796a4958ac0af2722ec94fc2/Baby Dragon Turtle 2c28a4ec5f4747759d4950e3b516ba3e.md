# Baby Dragon Turtle

Tags: Animal
DR: 4

```markdown
**Baby Dragon Turtle** Lvl 4
Body: 1, Mind: 0, Soul: 4
Armor Heavy + Ward 2,  Health 14/14, Speed 6.

Crafting: 0, Thieving: 0, Charm: 0, Nature: 2, Arcana: 3, Medicine: 0
Soul Strain - 0/8

**Traits:**
Shell Defence - # - Can recede into its shell. While receded gains -2 Damage and cannot do Actions or Movement, except to come out of its shell. This cannot be done next turn.

Spirit Animal - Gain 2 Ward on Rest.
Hold Breath - Can hold its breath for an hour without needing air.
Swimmer - Can swim its Speed when moving.
Flippers - Loses 3 Speed when trying to move on Land.

**Spells:**
0 SSt: Phantom Fishing Rod,  Control Elements
1 SSt: Water Ball,  Bless
2 SSt: Weightless,  Rain,  Freezing Wave, Conjure Spectral Claws, **Soul Shield**

**Items:**
Dragon Scales - 1d6 / 2 rounded down.
Bite - Body - 1 Damage.
```