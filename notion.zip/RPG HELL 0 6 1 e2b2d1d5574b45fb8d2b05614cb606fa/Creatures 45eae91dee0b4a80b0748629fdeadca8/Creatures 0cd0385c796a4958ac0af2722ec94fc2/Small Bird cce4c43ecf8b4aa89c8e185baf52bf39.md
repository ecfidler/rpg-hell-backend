# Small Bird

Tags: Animal
DR: 0

```markdown
**Small Bird** Lvl 0
Body: 0, Mind: 1, Soul: 0
Armor Unarmored,  Health 1/1, Speed 8.

Crafting: 0, Thieving: 1, Charm: 0, Nature: 0, Arcana: 0, Medicine: 0
Soul Strain - 0/0

**Traits:**
Peck - Body - Roll 1d6. On 5 or higher do 1 Damage.

Flight - the birb can fly

**Items:**
Feathers- 1d6
```