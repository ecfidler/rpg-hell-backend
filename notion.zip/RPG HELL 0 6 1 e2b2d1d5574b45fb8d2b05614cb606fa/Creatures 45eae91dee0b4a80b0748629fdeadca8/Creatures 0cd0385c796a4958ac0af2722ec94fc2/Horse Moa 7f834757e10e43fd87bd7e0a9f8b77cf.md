# Horse/Moa

Tags: Animal
DR: 1

```markdown
**Horse/Moa** Lvl 1
Body: 2, Mind: 0, Soul: 0
Armor Light,  Health 9/9, Speed 10.

Crafting: 0, Thieving: 0, Charm: 0, Nature: 2, Arcana: 0, Medicine: 0
Soul Strain - 0/0

**Traits:**
Slam - Attack - 1 Damage.
Far Traveler - ## - Move 3 times your Speed.

Strong Body - Can carry or pull 5 times its body weight.

**Spells:**

**Items:**

**Notes:**
```