# Panther

Tags: Animal
DR: 4

```markdown
**Panther** Lvl 4
Body: 4, Mind: 1, Soul: 0
Armor Medium,  Health 20/20, Speed 8.

Crafting: 0, Thieving: 3, Charm: 0, Nature: 2, Arcana: 0, Medicine: 0
Soul Strain - 0/0

**Traits:**
Powerful Claw - Attack - 3 Damage.

Nocturnal - P - Can see in the dark up to 6 tiles in front of it.
Climber - P - Can move your Speed up vertical walls without needing to roll or spending extra Speed.
High Jump - P - Can jump an additional 2 tiles vertically.

**Spells:**

**Items:**

**Notes:**
```