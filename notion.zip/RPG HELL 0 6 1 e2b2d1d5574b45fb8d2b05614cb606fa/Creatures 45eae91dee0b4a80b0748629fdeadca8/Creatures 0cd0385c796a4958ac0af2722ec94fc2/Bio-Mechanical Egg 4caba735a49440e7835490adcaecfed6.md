# Bio-Mechanical Egg

Tags: Construct, Monstrosity
DR: 1

```markdown
**Bio-Mechanical Egg** Lvl 1
Body: 2, Mind: 0, Soul: 0
Armor Unarmored,  Health 4/4, Speed 0.

Crafting: 0, Thieving: 0, Charm: 0, Nature: 6, Arcana: 0, Medicine: 0
Soul Strain - 0/0

**Traits:**
Consume Hachery - Attack - 1 damage. If this kills the target Hatch.
Hatch - ### - Reduce Nature by 1. At Nature 0 Hatch.

Construct - Does not require food, water, or air to function.

**Spells:**

**Items:**

```