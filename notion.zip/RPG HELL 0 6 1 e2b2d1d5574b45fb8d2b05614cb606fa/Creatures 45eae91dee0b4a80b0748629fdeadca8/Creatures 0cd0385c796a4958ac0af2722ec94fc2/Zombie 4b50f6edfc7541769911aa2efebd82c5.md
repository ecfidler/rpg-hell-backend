# Zombie

Tags: Undead
DR: 1

```markdown
**Zombie** Lvl 1
Body: 2, Mind: 0, Soul: 0
Armor Light,  Health 9/9, Speed 6.

Crafting: 0, Thieving: 0, Charm: 0, Nature: 0, Arcana: 0, Medicine: 0
Soul Strain - 0/0

**Traits:**
Swipe - Attack - 2 Damage.

Undead - Curse (6,4) - The creature is Undead. When this creature hits 0 or less health they roll deaths door rolls.

**Spells:**

**Items:**
Coin - 1d6
Tattered Cloth - 1

**Notes:**
```