# Bio-Mechanical Spider Queen

Tags: Construct, Monstrosity
DR: 8

```markdown
**Bio-Mechanical Spider Queen** Lvl 8
Body: 6, Mind: 2, Soul: 0
Armor Heavy +2 Ward,  Health 31/31, Speed 4.

Crafting: 6, Thieving: 0, Charm: 0, Nature: 0, Arcana: 2, Medicine: 0
Soul Strain - 0/6

**Traits:**
Spider Bite - Attack - 3 Damage. Roll 1d6, on 5/6 give Stun 1
Far Web Sling - Contest (##) - Roll a Contested Body Check on a target within Range 6. On success the target gets Webbed.
Large Web Lay - # - Place a layer of webbing within Burst 3 of the spider.
Brood Mother - ### - Lay an Egg on a spot within 1 tile.

Sticky Climber - Can scale vertical walls and ceilings without needing to roll.
Construct - Does not require food, water, or air to function.
Bio-Hackable - (6,4,4) - Roll Arcana. Can be hacked if the score is higher than the Hackable value.
Deathless - Can be revived with a Crafting score of 20 or higher (sum).
Forced Soul 3 - Get 6 Soul Strain, do not get any spells

**Spells:**

**Items:**
Scrap Metal - 3d6+3 lb
Mystery Meat - 2d6+1 lb
Silk - 4d6 lb
Soul Core - Roll (1d6 on 5/6 it is unbroken) x3
```