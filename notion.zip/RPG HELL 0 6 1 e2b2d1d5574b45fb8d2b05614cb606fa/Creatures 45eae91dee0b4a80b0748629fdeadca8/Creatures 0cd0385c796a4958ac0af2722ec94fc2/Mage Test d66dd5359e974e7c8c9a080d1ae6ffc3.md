# Mage Test

Tags: Humanoid
DR: 4

```markdown
**Mage Test** Lvl 4, Avian
Body: 0, Mind: 1, Soul: 4
Armor Soul Weave Cloak (Ward 1),  Health 12/12, Speed 8.
Locked [], Dice: 6

Crafting: 0, Thieving: 0, Charm: 0, Nature: 0, Arcana: 0, Medicine: 5
Soul Strain - 0/14

**Traits:**
Tome of Souls - Attack - 1 Dmg, Range 6, Gain an additional 2 Soul Strain
Rapier - Attack - 1 Dmg, ArmP, Move 2 tiles after attack.

(1) Split Soul - ### - Cleans 3.

(0) Avian - P - You are able to glide 1 tile for every 2 tiles you fall. This effect does not work if you are hindered in any way (Stunned, Burning, Grappled, ext.)
(1) Soul Manipulator - P - While soul is your Core Skill, Triple your Soul when Calculating Max Soul Strain instead of Doubling it.
(1) Soul Ward - P - When you take damage you can gain Ward 1, and gain 2 Soul Strain, then take the damage.
(2) Past and Future - P - You can now Lock two dice. When you would Lock a dice while having two Locked you may pick which Locked dice to replace.
(3) Healthy Hands - P - When you cast the Healing Hands Spell use your full Medicine roll instead of half.
(4) Reactive Explosions - P - When you do an area of effect spell, you can set one of the required dice to 5 (You still spend 3 dice, you just change 1 dice).

**Spells:**
(0) Control Elements - # -
(0) Soul Whip - Attack - 
(0) Pocket Dimension - # - 
(0) Poprocks - Attack - 
(1) Healing Hands - # - 
(1) Water Ball - Attack - 
(1) Conjure Fog - # - 
(1) Soul Grenade - ### - 
(1) Lightshow - ### - 
(2) Soul Skip - # -
(2) Invisibility - # - 
(2) Boulder Toss - ### - 
(2) Intrusive Thoughts - Contest - 
(3) Telekinesis - Contest - 
(3) Counterspell - # - 
(3) Swapper - Contest - 
(4) Chain Lightning - Attack -
(5) Death's Whisper - Attack - 

**Items:**
Coin - 15
Bandage - # - Target a Creature, cannot target undead or constructs. Heal the target 2 Health + Half your Medicine Rounded up.
Alchemist Tools - P - Allows for crafting potions and healing items.

**Notes:**
```