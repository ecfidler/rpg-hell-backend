# MoleFrog

Tags: Animal
DR: 0

```markdown
**MoleFrog** Lvl 0
Body: 1, Mind: 0, Soul: 0
Armor Unarmored,  Health 5/5, Speed 7.

Crafting: 0, Thieving: 0, Charm: 0, Nature: 1, Arcana: 0, Medicine: 0
Soul Strain - 0/0

**Traits:**
Weak Bite - Attack - Roll 1d6. On 5 or higher do 1 Damage.
Tunneler - ## - You can remove a number of tiles equal to your crafting stat. Different types of tiles cost more or less to dig through (Cost : Tiles removed). Soft (1:1), such as dirt or loose stones

Animal Tunneler - Gain the Tunneler trait, it uses Nature instead of Crafting 
Swimmer - Can swim its Speed when moving.
High Jump - P - Can jump an additional 2 tiles vertically.

**Spells:**

**Items:**
Coin - 1

**Notes:**

```