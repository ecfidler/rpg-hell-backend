# Corrupted Ancient Lifter Golem

Tags: Construct
DR: 1

```markdown
**Corrupted Ancient Lifter Golem** Lvl 1
Body: 2, Mind: 0, Soul: 0
Armor Light,  Health 9/9, Speed 8.

Crafting: 0, Thieving: 0, Charm: 0, Nature: 0, Arcana: 3, Medicine: 0
Soul Strain - 0/0

**Traits:**
Claw - Attack - 1 Damage.

Strong Body - Can carry or pull 5 times its body weight.
Hackable - (6,4) - Roll Mind/Theiving. Can be hacked if the score is higher than the Hackable value.
Construct - Does not require food, water, or air to function.

**Spells:**

**Items:**
Scrap Metal - 1d6 lb

**Notes:**
```