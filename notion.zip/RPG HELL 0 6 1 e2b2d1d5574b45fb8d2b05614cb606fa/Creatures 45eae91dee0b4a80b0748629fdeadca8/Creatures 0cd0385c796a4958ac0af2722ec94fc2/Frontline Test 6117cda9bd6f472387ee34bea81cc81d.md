# Frontline Test

Tags: Humanoid
DR: 4

```markdown
**Frontline Test** Lvl 4, Hellborn
Body: 4, Mind: 1, Soul: 0
Armor Platemail,  Health 24/24, Speed 6.
Locked [], Dice: 6

Crafting: 0, Thieving: 3, Charm: 0, Nature: 0, Arcana: 0, Medicine: 2
Soul Strain - 0/0

**Traits:**
Ancient Blade - Attack - 4 Dmg
Flintlock Rifle - Attack - 2 Dmg, Range 12, Loading, Two Handed

(1) Whirlwind - Attack - Do a Melee Attack against all creatures within 1 tile of you. You can only do this once per turn.
(1) Bash - Attack - Stun 3.
(4) Critical Strike - Attack+6 - Do a Melee Attack, it does Double damage.

(0) Hellborn - P - You cannot be damaged by Burn, and you reduce the time you are Frozen by 1 when you first become Frozen.
(1) Hearty - P - Gain additional Max Health equal to your Body. 
(2) Defender - P - When you use Overwatch and you hit a creature. That creature’s Speed is set to 0 and gets Webbed this turn.
(3) Slap Back - P - Spend your locked dice when using this trait. Make a melee attack on a creature who has hit you with a Melee attack.

**Spells:**

**Items:**
Coin - 15
Bandage - Target a Creature, cannot target undead or constructs. Heal the target 2 Health + Half your Medicine Rounded up.
Bandage - Target a Creature, cannot target undead or constructs. Heal the target 2 Health + Half your Medicine Rounded up.

**Notes:**
```