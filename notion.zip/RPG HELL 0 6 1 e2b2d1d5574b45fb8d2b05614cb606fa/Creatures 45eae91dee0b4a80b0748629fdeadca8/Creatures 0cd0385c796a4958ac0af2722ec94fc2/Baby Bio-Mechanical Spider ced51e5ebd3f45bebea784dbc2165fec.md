# Baby Bio-Mechanical Spider

Tags: Construct, Monstrosity
DR: 2

```markdown
**Baby Bio-Mechanical Spider** Lvl 2
Body: 2, Mind: 0, Soul: 0
Armor Light,  Health 8/8, Speed 8.

Crafting: 2, Thieving: 0, Charm: 0, Nature: 0, Arcana: 0, Medicine: 0
Soul Strain - 0/2

**Traits:**
Weak Bite - Attack - 1 Damage.
Web Sling - Contest (##) - Roll a Contested Body Check on a target within Range 4. On success the target gets Webbed.

Sticky Climber - Can scale vertical walls and ceilings without needing to roll.
Construct - Does not require food, water, or air to function.
Bio-Hackable - (6,4,4) - Roll Arcana. Can be hacked if the score is higher than the Hackable value.
Deathless - Can be revived with a Crafting score of 20 or higher (sum).
Forced Soul - Get 2 Soul Strain, do not get any spells

**Spells:**

**Items:**
Mystery Meat - 1d6 lb
```