# Creatures

[https://rpg-hell.notion.site/RPG-HELL-0-6-0-e2b2d1d5574b45fb8d2b05614cb606fa?pvs=4](../RPG%20HELL%200%206%201%20e2b2d1d5574b45fb8d2b05614cb606fa.md)

# Creature Creation

* Grunts have Light or Medium armor. (difficulty dependent), “boss/strong” has heavy (only have one of these)
* Damage Creatures do Lvl -1 Damage on hit. Use a weapon in the weapon tab for ideas
* Spellcasters have light armor and have 4-5 spells, including a lvl 0.
* HP is roughly same as normal, balance in game if needed.

# List

[Creatures](Creatures%2045eae91dee0b4a80b0748629fdeadca8/Creatures%200cd0385c796a4958ac0af2722ec94fc2.csv)

# Template

Steps for Creature Creation.
1: Duplicate template: 6 dots next to + when hovering. 
2: Edit template above (makes life easy). Try to name traits the same as others if copied.
3: Make a new line in the table above. Name/tag and DR (Lvl) appropriately. 
4: Hit open next to name of monster. 
5: Move Template from below into text field of new creature.

```markdown
**Name** Lvl #
Body: 0, Mind: 0, Soul: 0
Armor _,  Health _/_, Speed 8.

Crafting: 0, Thieving: 0, Charm: 0, Nature: 0, Arcana: 0, Medicine: 0
Soul Strain - 0/_

**Traits:**
Claw - Attack - 1 Damage.

**Spells:**

**Items:**
Coin - 15

**Notes:**
```