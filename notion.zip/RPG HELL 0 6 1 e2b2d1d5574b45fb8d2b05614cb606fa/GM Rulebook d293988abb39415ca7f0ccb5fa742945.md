# GM Rulebook

Below are a listing of rules and information when playing the game as a Game Master, otherwise known as a GM.

# Combat for the GM

     When designing a combat encounter the GM needs to decide how to fight the players. A good way of doing this is to first decide what kind of creatures the players are going to fight. All Creatures have a level associated with them. Take the players combined level and have the creatures combined level be somewhere around 1 to 2 points away from this total. Harder or easer combats can have this value be shifted more in either direction.

<aside>
🐢 Typically I only have 3 or 4 different creature types in a combat (A lone Boss 1 higher, 1-2 elites same lvl, and a bunch of grunts 1 less). It makes controlling them easy and leaves less info for me to think over.

</aside>

     Ways to make the combat interesting are to have an alternate or secondary win condition. Basically, this means that they need to defend a creature or group of creatures, or open a floodgate, in addition to just killing everything in the encounter.

Creatures do not have locked dice, overwatch is done with only 1 dice on its turn. Mages dont have a locked dice and get Stun 1 instead on their turn when doing a reaction spell.

# Outside Combat for the GM

     Checks are typically done based on difficulty. 1 success is easy, 2 is normal, 3 is difficult, 4 is hard, etc. When just meeting the requirements the players will pass but something unexpected will happen. An example: trying to hide but only barley making it, the creature will be hidden but will nock something over and have the guard look for them.

| Check Value | Meet | 1 over | 2+ over |
| --- | --- | --- | --- |
| Easy (1) | Pass, with a But | Pass | Pass |
| Normal (2) | Pass, with a But | Pass | Pass with an And |
| Difficult (3) | Pass with a But | Pass | Pass with an And |
| Hard (4) | Pass with a But | Pass with a But | Pass |

# Mysc Rules

### Armor Weirdness

Knockback, Burn, and Soul Strain does not get affected by Armor/Ward and does not break Ward
Attacks that do not do damage do not break Ward (like Poprocks)

### Hacking

Within 1 Tile of a target, roll Mind/Thieving against its Hackable score. On a success you have four options depending on what is hacked: Control, Probe, Data Manipulation, or Restart. Once you do one of these actions you must roll another Mind check to do another action.

**Control** - You can force the construct to do an action in its action table or make it move its Speed. An example is to open a door or attack another construct.

**Probe** - You can look through the construct’s memory to find information about a set topic. Examples include finding passwords, names, locations, or history. This is also what lets you look through the constructs “eyes” such as with security cameras.

**Data Manipulation**- You can edit or remove data that you have found with Probe. Removed data is lost to the Construct and cannot be found again with a Probe. You must have found the modified data with Probe first to use this action.

**Restart** - You force the Construct to restart giving it two stacks of Frozen. Doing this does not let anyone Hack the Construct until it is un-Frozen.

### Inspiration

The GM may grant the players “Inspiration” for actions which lets them [Lock](https://docs.google.com/document/d/16UAppeRvBLRCx6qyCgVCdJ-82SIm1ifkDeiQd5ab20A/edit?pli=1#heading=h.pjwde8e5w94m) a 6.

### Advantage/Disadvantage

Advantage - you may reroll a dice.

Disadvantage - you must reroll the highest dice

### Swimming/Climbing/Jumping

You move at half your Speed when swimming or climbing. In some situations the GM can ask for a Body Roll to swim faster or succeed/fail to climb.

You can jump vertically a number of tiles equal to your Body plus 1. You can do a standing jump equal to your Body, and a running long jump equal to your Body plus 2.

### Delayed Actions

State what you wish to do and give the appropriate dice. Then state what conditions activate the action. If the conditions are met you do the action, even if it is not your turn. If the conditions are not met then the dice and action are lost.

### Item Carry Limit

Optional Rule : By default you can carry 1/4 of a tile worth of stuff without using your hands. This is without any bags. You can use your hands to get an additional 1/4 + (1/4)*Body tiles.

# Creature Creation

Grunts have Light or Medium armor. (difficulty dependent), “boss/strong” has heavy (only have one of these)
Damage Creatures do Lvl -1 Damage on hit. Use a weapon in the weapon tab for ideas
Spellcasters have light armor and have 4-5 spells, including a lvl 0.
HP is roughly same as normal, balance in game if needed.

# Extra Challenge

To increase the difficulty of the game without increasing monster rates or requirements for rolling use the following ruleset.

### Death’s Door Penalties

When a player is put on Death’s Door roll a dice and give them one of the following debuffs.

| Roll | Name | Effect |
| --- | --- | --- |
| 1 | Loose a Limb | Roll on Table Below |
| 2 | Bleeding Out | Increase the death roll on Deaths Door roll from 2 to 3. Goes away on Rest |
| 3 | Serious Gash | Loose 3 Max Health |
| 4 | Injured Leg | Reduce Speed by 1 |
| 5 | Exhaustion | Get Stun 1 every turn, until next Rest |
| 6 | No Injury | No Injury |

| Roll | Limb Lost | Effect |
| --- | --- | --- |
| 1 | Arm | Loose your arm and 1 Body |
| 2 | Serious Concussion | Get Stun 3 for next turn and Loose 1 Mind |
| 3 | Deep Panic | You can only Move next turn and Loose 1 Soul |
| 4 | Leg | Loose a Leg and 3 Speed |
| 5 | Eye | Loose an eye. Roll 1 less dice on Sight related Rolls. If both eyes are lost become Blind. |
| 6 | Ear | Loose an Ear. Roll 1 Less dice on Hearing related Rolls. If both ears are lost become Deaf. |

# Wild Magic Table

| Roll | Effect |
| --- | --- |
| 1,1 | Get a Death’s Door Penalty, as listed above |
| 1,2 | You turn into a Fish for 10 minutes. |
| 1,3 |  |
| 1,4 |  |
| 1,5 |  |
| 1,6 |  |
| 2,1 | A wild Box Turtle appears near you. |
| 2,2 |  |
| 2,3 | The spell Invisibility is cast on you. |
| 2,4 |  |
| 2,5 | You loose 1 item at random from your inventory. |
| 2,6 |  |
| 3,1 | 3d6 wild Chickens appear near you. |
| 3,2 |  |
| 3,3 |  |
| 3,4 | You can only see 1 color in different shades. This effect lasts until your next Rest. |
| 3,5 |  |
| 3,6 | The spell Bless is cast on you. |
| 4,1 |  |
| 4,2 | Invert the gravity of everything within 8 tiles of you. |
| 4,3 |  |
| 4,4 | Gain 6 Burn then the spell Detonate is cast on you. |
| 4,5 |  |
| 4,6 |  |
| 5,1 | The spell Soul Shatter is cast on you. |
| 5,2 |  |
| 5,3 | A wild Panther appears near you. The spell Beast Bond is cast on it through you. |
| 5,4 |  |
| 5,5 | Swap Places with a random Creature you can see. |
| 5,6 |  |
| 6,1 |  |
| 6,2 |  |
| 6,3 |  |
| 6,4 |  |
| 6,5 | You get all the effects of a Rest. |
| 6,6 | A large flawless Gem worth 1d6 hundred thousand gold appears somewhere near you. |

# IDEAS FROM GINGY

Trait People - People in peoples backstory that are tied to a theme or requirement in people’s character

Customizable weapons - Tags are given to weapons with exp instead of just picking one

Have a section in traits for 

```json
{
   "creature": {
      "name": "name",
      "race": "race",
      "level": "level",
      "stats": {
         "body": 0,
         "mind": 0,
         "soul": 0,
         "arcana": 0,
         "charm": 0,
         "crafting": 0,
         "medicine": 0,
         "nature": 0,
         "thiefing": 0,
         "curHealth": 0,
         "speedBonus": 0
      },
      "stackEffects": [],
      "traits": [],
      "spells": [],
      "items": [
         {"gold": 0}
      ],
      "notes": []
   }
}
```